import { PrismaClient } from "@prisma/client";

// Export a singleton Prisma client instance
export const prisma = new PrismaClient();
