import { GoogleGenAI } from "@google/genai";
import "dotenv/config";

class AIService {
  private client: GoogleGenAI;

  constructor() {
    this.client = new GoogleGenAI({
      apiKey: process.env.GEMINI_API_KEY,
      httpOptions: {
        headers: { "User-Agent": "aistudio-build" },
      },
    });
  }

  /**
   * Helper method for delay
   */
  private delay(ms: number) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  /**
   * Generate content using the Gemini model with automatic retries for 503 errors.
   * Centralizes all AI calls.
   */
  async generate(options: {
    prompt: string;
    systemInstruction?: string;
    model?: string;
    temperature?: number;
    retries?: number;
  }): Promise<string> {
    const modelName = options.model || "gemini-3.6-flash";
    const temperature = options.temperature ?? 0.7;
    const maxRetries = options.retries ?? 3;
    let attempt = 0;

    while (attempt <= maxRetries) {
      try {
        const response = await this.client.models.generateContent({
          model: modelName,
          contents: options.prompt,
          config: {
            systemInstruction: options.systemInstruction,
            temperature: temperature,
          },
        });
        return response.text || "";
      } catch (error: any) {
        attempt++;
        
        // Check if it's a 503 Service Unavailable or 429 Too Many Requests
        const isOverloaded = error?.status === 503 || error?.message?.includes("503") || error?.status === 429 || error?.message?.includes("429");
        
        if (isOverloaded && attempt <= maxRetries) {
          console.warn(`Gemini API overloaded (Attempt ${attempt}/${maxRetries}). Retrying in a moment...`);
          const waitTime = Math.pow(2, attempt) * 1000; // Exponential backoff: 2s, 4s, 8s...
          await this.delay(waitTime);
          continue;
        }

        console.warn(`Gemini API Error (Final Attempt ${attempt}):`, error.message || error);

        // If max retries reached or it's a different error, throw or return friendly message
        if (isOverloaded) {
          return "عذراً، الخوادم تواجه ضغطاً عالياً حالياً (High Demand). يرجى المحاولة بعد قليل.";
        }
        
        throw new Error("Failed to generate content from AI");
      }
    }
    
    return "عذراً، حدث خطأ غير متوقع.";
  }
}

// Export a singleton instance of the AI Service
export const aiService = new AIService();
