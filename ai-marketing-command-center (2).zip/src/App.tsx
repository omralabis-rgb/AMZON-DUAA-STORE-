import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import DashboardLayout from './components/layout/DashboardLayout';
import Dashboard from './pages/Dashboard';
import PlaceholderPage from './pages/PlaceholderPage';
import Advisor from './pages/Advisor';
import AdvisorsManager from './pages/AdvisorsManager';
import Products from './pages/Products';
import AgentEngine from './pages/AgentEngine';
import AIAssistantPage from './pages/AIAssistantPage';
import SaharaMarketManifesto from './pages/SaharaMarketManifesto';

export default function App() {
  return (
    <Router>
      <Routes>
        {/* Independent standalone route */}
        <Route path="/sahara-market" element={<SaharaMarketManifesto />} />
        
        {/* Main Application Layout */}
        <Route path="/" element={<DashboardLayout />}>
          <Route index element={<Dashboard />} />
          <Route path="advisor" element={<Advisor />} />
          <Route path="advisors-manager" element={<AdvisorsManager />} />
          <Route path="agent" element={<AgentEngine />} />
          <Route path="products" element={<Products />} />
          <Route path="ai-assistant" element={<AIAssistantPage />} />
          <Route path="campaigns" element={<PlaceholderPage title="الحملات" />} />
          <Route path="content-studio" element={<PlaceholderPage title="Content Studio" />} />
          <Route path="calendar" element={<PlaceholderPage title="التقويم" />} />
          <Route path="approval-center" element={<PlaceholderPage title="Approval Center" />} />
          <Route path="accounts" element={<PlaceholderPage title="الحسابات المتصلة" />} />
          <Route path="analytics" element={<PlaceholderPage title="Analytics" />} />
          <Route path="brand" element={<PlaceholderPage title="Brand DNA" />} />
          <Route path="settings" element={<PlaceholderPage title="الإعدادات" />} />
          <Route path="security" element={<PlaceholderPage title="Security" />} />
          <Route path="audit-logs" element={<PlaceholderPage title="Audit Logs" />} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Route>
      </Routes>
    </Router>
  );
}
