import { useState, useEffect } from "react";
import { Users, Plus, BrainCircuit, Trash2, Edit2, Loader2, Save } from "lucide-react";

interface AdvisorInfo {
  id: string;
  name: string;
  roleDescription: string;
  systemPrompt: string;
  model: string;
  temperature: number;
}

export default function AdvisorsManager() {
  const [advisors, setAdvisors] = useState<AdvisorInfo[]>([]);
  const [loading, setLoading] = useState(true);
  const [isEditing, setIsEditing] = useState<string | null>(null);
  
  const [formData, setFormData] = useState<Partial<AdvisorInfo>>({
    name: "",
    roleDescription: "",
    systemPrompt: "",
    model: "gemini-3.8-flash",
    temperature: 0.7
  });

  useEffect(() => {
    fetchAdvisors();
  }, []);

  const fetchAdvisors = async () => {
    try {
      const res = await fetch("/api/advisors");
      const contentType = res.headers.get("content-type");
      if (contentType && contentType.includes("application/json")) {
        const data = await res.json();
        setAdvisors(data);
      } else {
        console.error("Received non-JSON response, likely server is restarting.");
      }
    } catch (e) {
      console.error("Failed to fetch advisors", e);
    } finally {
      setLoading(false);
    }
  };

  const handleEdit = (advisor: AdvisorInfo) => {
    setFormData(advisor);
    setIsEditing(advisor.id);
  };

  const handleAddNew = () => {
    setFormData({
      name: "",
      roleDescription: "",
      systemPrompt: "",
      model: "gemini-3.8-flash",
      temperature: 0.7
    });
    setIsEditing("new");
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const url = isEditing === "new" ? "/api/advisors" : `/api/advisors/${isEditing}`;
      const method = isEditing === "new" ? "POST" : "PUT";
      
      const res = await fetch(url, {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formData)
      });
      
      if (res.ok) {
        setIsEditing(null);
        fetchAdvisors();
      }
    } catch (e) {
      console.error(e);
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm("هل أنت متأكد من حذف هذا المستشار؟")) return;
    try {
      const res = await fetch(`/api/advisors/${id}`, { method: "DELETE" });
      if (res.ok) {
        fetchAdvisors();
      }
    } catch (e) {
      console.error(e);
    }
  };

  if (loading) {
    return <div className="flex h-full items-center justify-center"><Loader2 className="w-8 h-8 text-blue-500 animate-spin" /></div>;
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-2">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 bg-blue-600/20 rounded-xl flex items-center justify-center border border-blue-500/20">
            <Users className="w-6 h-6 text-blue-400" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-white">إدارة المستشارين</h1>
            <p className="text-slate-500 text-sm mt-1">أضف وعدل مستشاري الذكاء الاصطناعي وخصص تعليماتهم</p>
          </div>
        </div>
        {!isEditing && (
          <button 
            onClick={handleAddNew}
            className="bg-blue-600 hover:bg-blue-500 text-white px-4 py-2 rounded-xl font-bold text-sm flex items-center gap-2 transition-colors shadow-lg shadow-blue-900/20"
          >
            <Plus className="w-4 h-4" /> مستشار جديد
          </button>
        )}
      </div>

      {isEditing ? (
        <div className="bg-[#11141b] rounded-3xl border border-slate-800 p-6 shadow-xl max-w-4xl">
          <h2 className="text-lg font-bold text-white mb-6 border-b border-slate-800 pb-4">
            {isEditing === "new" ? "إضافة مستشار جديد" : "تعديل بيانات المستشار"}
          </h2>
          <form onSubmit={handleSave} className="space-y-5">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
              <div>
                <label className="block text-xs font-bold text-slate-400 mb-2">الاسم (يظهر للمستخدم)</label>
                <input 
                  required 
                  type="text" 
                  value={formData.name || ""} 
                  onChange={e => setFormData({...formData, name: e.target.value})} 
                  className="w-full bg-[#161a23] border border-slate-700 rounded-xl px-4 py-3 text-white text-sm focus:outline-none focus:border-blue-500" 
                  placeholder="مثال: خبير الإعلانات الممولة"
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-400 mb-2">الوصف السريع للتخصص</label>
                <input 
                  required 
                  type="text" 
                  value={formData.roleDescription || ""} 
                  onChange={e => setFormData({...formData, roleDescription: e.target.value})} 
                  className="w-full bg-[#161a23] border border-slate-700 rounded-xl px-4 py-3 text-white text-sm focus:outline-none focus:border-blue-500" 
                  placeholder="مثال: متخصص في تحسين حملات جوجل و فيسبوك"
                />
              </div>
              <div className="md:col-span-2">
                <label className="block text-xs font-bold text-slate-400 mb-2">التعليمات الصارمة (System Prompt)</label>
                <textarea 
                  required 
                  rows={6} 
                  value={formData.systemPrompt || ""} 
                  onChange={e => setFormData({...formData, systemPrompt: e.target.value})} 
                  className="w-full bg-[#161a23] border border-slate-700 rounded-xl px-4 py-3 text-white text-sm focus:outline-none focus:border-blue-500 custom-scrollbar leading-relaxed" 
                  placeholder="أنت مستشار متخصص في الإعلانات. دورك هو..."
                />
                <p className="text-xs text-slate-500 mt-2">هذه التعليمات هي التي ستشكل شخصية المستشار وكيفية رده وتوجيهاته.</p>
              </div>
            </div>
            <div className="flex justify-end gap-3 pt-4 border-t border-slate-800">
              <button 
                type="button" 
                onClick={() => setIsEditing(null)}
                className="px-6 py-2.5 rounded-xl font-bold text-sm text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
              >
                إلغاء
              </button>
              <button 
                type="submit" 
                className="bg-blue-600 hover:bg-blue-500 text-white px-8 py-2.5 rounded-xl font-bold text-sm flex items-center gap-2 transition-colors shadow-lg shadow-blue-900/20"
              >
                <Save className="w-4 h-4" /> حفظ المستشار
              </button>
            </div>
          </form>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
          {advisors.map(adv => (
            <div key={adv.id} className="bg-[#11141b] rounded-3xl border border-slate-800 p-6 flex flex-col relative overflow-hidden group hover:border-slate-700 transition-colors shadow-lg">
              <div className="flex justify-between items-start mb-4">
                <div className="w-12 h-12 bg-blue-500/10 rounded-2xl flex items-center justify-center border border-blue-500/20">
                  <BrainCircuit className="w-6 h-6 text-blue-400" />
                </div>
                <div className="flex gap-2">
                  <button onClick={() => handleEdit(adv)} className="p-2 bg-slate-800 hover:bg-slate-700 rounded-lg text-slate-400 hover:text-white transition-colors">
                    <Edit2 className="w-4 h-4" />
                  </button>
                  <button onClick={() => handleDelete(adv.id)} className="p-2 bg-red-500/10 hover:bg-red-500/20 rounded-lg text-red-400 transition-colors">
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
              <h3 className="text-white font-bold text-lg mb-1">{adv.name}</h3>
              <p className="text-slate-400 text-sm mb-4">{adv.roleDescription}</p>
              
              <div className="mt-auto pt-4 border-t border-slate-800/50">
                <p className="text-xs text-slate-500 line-clamp-2">
                  <span className="font-bold text-slate-400">Prompt: </span>
                  {adv.systemPrompt}
                </p>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
