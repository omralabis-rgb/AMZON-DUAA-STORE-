import { useState, useRef, useEffect } from "react";
import { Sparkles, Send, Loader2, User, Users } from "lucide-react";
import Markdown from "react-markdown";

interface Message {
  role: "user" | "model";
  text: string;
}

interface AdvisorInfo {
  id: string;
  name: string;
  roleDescription: string;
  systemPrompt: string;
}

export default function Advisor() {
  const [advisors, setAdvisors] = useState<AdvisorInfo[]>([]);
  const [activeAdvisorId, setActiveAdvisorId] = useState<string>("");
  const [chatHistories, setChatHistories] = useState<Record<string, Message[]>>({});
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    fetchAdvisors();
  }, []);

  const fetchAdvisors = async () => {
    try {
      const res = await fetch("/api/advisors");
      const contentType = res.headers.get("content-type");
      if (contentType && contentType.includes("application/json")) {
        const data: AdvisorInfo[] = await res.json();
        setAdvisors(data);
        if (data.length > 0 && !activeAdvisorId) {
          setActiveAdvisorId(data[0].id);
          
          // Initialize history if empty
          const initialHistories = { ...chatHistories };
          data.forEach(adv => {
            if (!initialHistories[adv.id]) {
              initialHistories[adv.id] = [{ 
                role: "model", 
                text: `أهلاً بك. أنا ${adv.name}، ${adv.roleDescription} كيف يمكنني مساعدتك اليوم؟` 
              }];
            }
          });
          setChatHistories(initialHistories);
        }
      } else {
        console.error("Received non-JSON response from /api/advisors");
      }
    } catch (e) {
      console.error("Failed to fetch advisors", e);
    }
  };

  const activeMessages = chatHistories[activeAdvisorId];

  useEffect(() => {
    if (activeMessages) {
      messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
    }
  }, [activeMessages]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || loading || !activeAdvisorId) return;

    const userMessage = input.trim();
    setInput("");
    
    setChatHistories(prev => ({
      ...prev,
      [activeAdvisorId]: [...(prev[activeAdvisorId] || []), { role: "user", text: userMessage }]
    }));
    
    setLoading(true);

    try {
      const currentHistory = chatHistories[activeAdvisorId] || [];
      const conversationText = currentHistory
        .map(m => (m.role === "user" ? `User: ${m.text}` : `Advisor: ${m.text}`))
        .join("\\n") + `\\nUser: ${userMessage}\\nAdvisor:`;

      const res = await fetch("/api/advisor", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ 
          prompt: conversationText,
          advisorId: activeAdvisorId 
        })
      });

      const data = await res.json();
      
      if (res.ok) {
        setChatHistories(prev => ({
          ...prev,
          [activeAdvisorId]: [...(prev[activeAdvisorId] || []), { role: "model", text: data.text }]
        }));
      } else {
        setChatHistories(prev => ({
          ...prev,
          [activeAdvisorId]: [...(prev[activeAdvisorId] || []), { role: "model", text: "حدث خطأ أثناء معالجة طلبك." }]
        }));
      }
    } catch (error) {
      setChatHistories(prev => ({
        ...prev,
        [activeAdvisorId]: [...(prev[activeAdvisorId] || []), { role: "model", text: "حدث خطأ في الاتصال بالخادم." }]
      }));
    } finally {
      setLoading(false);
    }
  };

  const activeAdvisor = advisors.find(a => a.id === activeAdvisorId);

  return (
    <div className="flex flex-col lg:flex-row h-[calc(100vh-5rem)] bg-[#0a0a0f] text-slate-200 font-sans">
      
      {/* Sidebar Selector */}
      <div className="w-full lg:w-72 flex flex-col shrink-0 border-l border-slate-800/60 bg-[#0a0a0f] p-4 h-full overflow-y-auto custom-scrollbar">
        <div className="flex items-center gap-2 mb-6 px-2">
          <Sparkles className="w-5 h-5 text-purple-400" />
          <h2 className="font-semibold text-lg text-slate-100">المستشارون</h2>
        </div>
        
        <div className="space-y-1.5">
          {advisors.map(adv => (
            <button
              key={adv.id}
              onClick={() => setActiveAdvisorId(adv.id)}
              className={`w-full text-right p-3 rounded-xl transition-all duration-200 flex items-center gap-3 ${
                activeAdvisorId === adv.id 
                  ? "bg-slate-800/80 text-slate-100" 
                  : "hover:bg-slate-800/40 text-slate-400 hover:text-slate-200"
              }`}
            >
              <div className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 ${
                activeAdvisorId === adv.id ? "bg-purple-500/20 text-purple-400" : "bg-slate-800/50 text-slate-500"
              }`}>
                <Sparkles className="w-4 h-4" />
              </div>
              <div className="truncate text-right flex-1">
                <h3 className={`font-medium text-sm truncate ${activeAdvisorId === adv.id ? "text-slate-100" : ""}`}>
                  {adv.name}
                </h3>
              </div>
            </button>
          ))}
          
          {advisors.length === 0 && (
            <div className="text-center p-4 text-slate-500 text-sm">جاري التحميل...</div>
          )}
        </div>
      </div>

      {/* Main Chat Area (Gemini Style) */}
      <div className="flex-1 flex flex-col relative h-full">
        {/* Top Header */}
        {activeAdvisor && (
          <div className="absolute top-0 left-0 right-0 h-16 bg-gradient-to-b from-[#0a0a0f] to-transparent z-10 pointer-events-none flex items-center px-6">
             {/* Gradient fade for smooth scrolling under top */}
          </div>
        )}

        {/* Messages Container */}
        <div className="flex-1 overflow-y-auto px-4 md:px-8 pb-32 pt-6 custom-scrollbar">
          <div className="max-w-4xl mx-auto space-y-8 flex flex-col">
            {(activeMessages || []).map((msg, index) => (
              <div key={index} className={`flex w-full ${msg.role === "user" ? "justify-end" : "justify-start"}`}>
                
                {msg.role === "user" ? (
                  // User Message Style (Gemini: simple bubble)
                  <div className="bg-slate-800/80 text-slate-100 px-5 py-3 rounded-3xl rounded-tr-sm max-w-[85%] md:max-w-[75%] shadow-sm">
                    <div className="whitespace-pre-wrap text-[15px] leading-relaxed">
                      {msg.text}
                    </div>
                  </div>
                ) : (
                  // Assistant Message Style (Gemini: icon left/right, no bubble, full width text)
                  <div className="flex gap-4 w-full max-w-full">
                    <div className="w-8 h-8 rounded-full shrink-0 flex items-center justify-center bg-gradient-to-br from-purple-500 to-indigo-500 text-white mt-1 shadow-sm">
                      <Sparkles className="w-4 h-4" />
                    </div>
                    <div className="flex-1 markdown-body prose prose-invert max-w-none text-[15px] leading-relaxed text-slate-200">
                      <Markdown>{msg.text}</Markdown>
                    </div>
                  </div>
                )}
              </div>
            ))}

            {loading && (
              <div className="flex w-full justify-start">
                <div className="flex gap-4 w-full">
                  <div className="w-8 h-8 rounded-full shrink-0 flex items-center justify-center bg-gradient-to-br from-purple-500 to-indigo-500 text-white mt-1 shadow-sm animate-pulse">
                    <Sparkles className="w-4 h-4" />
                  </div>
                  <div className="flex-1 flex items-center text-slate-400">
                    <Loader2 className="w-5 h-5 animate-spin ml-2" />
                    <span className="text-sm">المستشار يكتب...</span>
                  </div>
                </div>
              </div>
            )}
            <div ref={messagesEndRef} className="h-4" />
          </div>
        </div>

        {/* Input Area (Gemini Style) */}
        <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-[#0a0a0f] via-[#0a0a0f] to-transparent pt-10 pb-6 px-4 md:px-8">
          <div className="max-w-4xl mx-auto">
            <form 
              onSubmit={handleSubmit} 
              className="relative flex items-end bg-[#161a23] border border-slate-700/60 rounded-[32px] px-2 py-2 shadow-lg focus-within:ring-1 focus-within:ring-slate-500 focus-within:border-slate-500 transition-all"
            >
              <textarea
                value={input}
                onChange={(e) => {
                  setInput(e.target.value);
                  // Auto-resize
                  e.target.style.height = 'auto';
                  e.target.style.height = Math.min(e.target.scrollHeight, 200) + 'px';
                }}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    if(input.trim() && !loading) handleSubmit(e);
                  }
                }}
                placeholder="اسأل المستشار عن أي شيء..."
                className="flex-1 max-h-48 bg-transparent border-none focus:outline-none text-slate-100 px-4 py-3 text-[15px] resize-none overflow-y-auto custom-scrollbar"
                rows={1}
                disabled={loading || !activeAdvisorId}
                style={{ minHeight: '48px' }}
              />
              <button
                type="submit"
                disabled={loading || !input.trim() || !activeAdvisorId}
                className="w-10 h-10 shrink-0 bg-white text-slate-900 disabled:bg-slate-700 disabled:text-slate-400 rounded-full flex items-center justify-center m-1 transition-colors hover:bg-slate-200"
              >
                <Send className="w-4 h-4 rtl:-scale-x-100 ml-0.5" />
              </button>
            </form>
            <div className="text-center mt-3">
              <span className="text-[11px] text-slate-500">
                قد يخطئ المستشارون أحياناً. يرجى التحقق من المعلومات المهمة.
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
