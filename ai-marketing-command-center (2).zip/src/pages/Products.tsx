import { useState, useEffect } from "react";
import { Package, Plus, Edit2, Trash2, Loader2, Save, Target, Tag, DollarSign, Sparkles } from "lucide-react";

interface Product {
  id: string;
  name: string;
  description: string;
  price: number | null;
  category: string | null;
  targetAudience: string | null;
  features: string | null;
}

export default function Products() {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [isEditing, setIsEditing] = useState<string | null>(null);

  const [formData, setFormData] = useState<Partial<Product>>({
    name: "",
    description: "",
    price: null,
    category: "",
    targetAudience: "",
    features: ""
  });

  useEffect(() => {
    fetchProducts();
  }, []);

  const fetchProducts = async () => {
    try {
      const res = await fetch("/api/products");
      const contentType = res.headers.get("content-type");
      if (contentType && contentType.includes("application/json")) {
        const data = await res.json();
        setProducts(data);
      } else {
        console.error("Received non-JSON response from /api/products");
      }
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  const handleEdit = (product: Product) => {
    setFormData(product);
    setIsEditing(product.id);
  };

  const handleAddNew = () => {
    setFormData({
      name: "",
      description: "",
      price: null,
      category: "",
      targetAudience: "",
      features: ""
    });
    setIsEditing("new");
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const url = isEditing === "new" ? "/api/products" : `/api/products/${isEditing}`;
      const method = isEditing === "new" ? "POST" : "PUT";
      
      const res = await fetch(url, {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formData)
      });
      
      if (res.ok) {
        setIsEditing(null);
        fetchProducts();
      }
    } catch (error) {
      console.error(error);
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm("هل أنت متأكد من حذف هذا المنتج؟")) return;
    try {
      const res = await fetch(`/api/products/${id}`, { method: "DELETE" });
      if (res.ok) {
        fetchProducts();
      }
    } catch (error) {
      console.error(error);
    }
  };

  if (loading) {
    return <div className="flex h-full items-center justify-center"><Loader2 className="w-8 h-8 text-blue-500 animate-spin" /></div>;
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-2">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 bg-blue-600/20 rounded-xl flex items-center justify-center border border-blue-500/20">
            <Package className="w-6 h-6 text-blue-400" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-white">إدارة المنتجات</h1>
            <p className="text-slate-500 text-sm mt-1">البيانات المرجعية (Source of Truth) لحملاتك التسويقية</p>
          </div>
        </div>
        {!isEditing && (
          <button 
            onClick={handleAddNew}
            className="bg-blue-600 hover:bg-blue-500 text-white px-4 py-2 rounded-xl font-bold text-sm flex items-center gap-2 transition-colors shadow-lg shadow-blue-900/20"
          >
            <Plus className="w-4 h-4" /> إضافة منتج جديد
          </button>
        )}
      </div>

      {isEditing ? (
        <div className="bg-[#11141b] rounded-3xl border border-slate-800 p-6 shadow-xl max-w-4xl mx-auto">
          <h2 className="text-lg font-bold text-white mb-6 border-b border-slate-800 pb-4">
            {isEditing === "new" ? "إضافة منتج/خدمة جديدة" : "تعديل بيانات المنتج"}
          </h2>
          <form onSubmit={handleSave} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
              <div className="md:col-span-2">
                <label className="block text-xs font-bold text-slate-400 mb-2">اسم المنتج / الخدمة</label>
                <div className="relative">
                  <Package className="absolute right-3 top-3 w-5 h-5 text-slate-500" />
                  <input 
                    required 
                    type="text" 
                    value={formData.name || ""} 
                    onChange={e => setFormData({...formData, name: e.target.value})} 
                    className="w-full bg-[#161a23] border border-slate-700 rounded-xl px-4 py-3 pr-10 text-white text-sm focus:outline-none focus:border-blue-500" 
                    placeholder="مثال: تطبيق الذكاء الاصطناعي للمبيعات"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-400 mb-2">الفئة (Category)</label>
                <div className="relative">
                  <Tag className="absolute right-3 top-3 w-5 h-5 text-slate-500" />
                  <input 
                    type="text" 
                    value={formData.category || ""} 
                    onChange={e => setFormData({...formData, category: e.target.value})} 
                    className="w-full bg-[#161a23] border border-slate-700 rounded-xl px-4 py-3 pr-10 text-white text-sm focus:outline-none focus:border-blue-500" 
                    placeholder="برمجيات، استشارات، إلخ."
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-400 mb-2">السعر (اختياري)</label>
                <div className="relative">
                  <DollarSign className="absolute right-3 top-3 w-5 h-5 text-slate-500" />
                  <input 
                    type="number" 
                    step="0.01"
                    value={formData.price || ""} 
                    onChange={e => setFormData({...formData, price: parseFloat(e.target.value) || null})} 
                    className="w-full bg-[#161a23] border border-slate-700 rounded-xl px-4 py-3 pr-10 text-white text-sm focus:outline-none focus:border-blue-500" 
                    placeholder="0.00"
                  />
                </div>
              </div>

              <div className="md:col-span-2">
                <label className="block text-xs font-bold text-slate-400 mb-2">وصف تفصيلي (Pitch)</label>
                <textarea 
                  required 
                  rows={3} 
                  value={formData.description || ""} 
                  onChange={e => setFormData({...formData, description: e.target.value})} 
                  className="w-full bg-[#161a23] border border-slate-700 rounded-xl px-4 py-3 text-white text-sm focus:outline-none focus:border-blue-500 custom-scrollbar leading-relaxed" 
                  placeholder="اشرح فوائد المنتج بشكل يجذب العميل..."
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-400 mb-2">الجمهور المستهدف (Target Audience)</label>
                <div className="relative">
                  <Target className="absolute right-3 top-3 w-5 h-5 text-slate-500" />
                  <input 
                    type="text" 
                    value={formData.targetAudience || ""} 
                    onChange={e => setFormData({...formData, targetAudience: e.target.value})} 
                    className="w-full bg-[#161a23] border border-slate-700 rounded-xl px-4 py-3 pr-10 text-white text-sm focus:outline-none focus:border-blue-500" 
                    placeholder="مثال: رواد الأعمال، أصحاب المتاجر..."
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-400 mb-2">الميزات الرئيسية (Features)</label>
                <div className="relative">
                  <Sparkles className="absolute right-3 top-3 w-5 h-5 text-slate-500" />
                  <input 
                    type="text" 
                    value={formData.features || ""} 
                    onChange={e => setFormData({...formData, features: e.target.value})} 
                    className="w-full bg-[#161a23] border border-slate-700 rounded-xl px-4 py-3 pr-10 text-white text-sm focus:outline-none focus:border-blue-500" 
                    placeholder="سرعة، أمان، واجهة سهلة (افصل بفاصلة)"
                  />
                </div>
              </div>
            </div>

            <div className="flex justify-end gap-3 pt-6 border-t border-slate-800">
              <button 
                type="button" 
                onClick={() => setIsEditing(null)}
                className="px-6 py-2.5 rounded-xl font-bold text-sm text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
              >
                إلغاء
              </button>
              <button 
                type="submit" 
                className="bg-blue-600 hover:bg-blue-500 text-white px-8 py-2.5 rounded-xl font-bold text-sm flex items-center gap-2 transition-colors shadow-lg shadow-blue-900/20"
              >
                <Save className="w-4 h-4" /> حفظ المنتج
              </button>
            </div>
          </form>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {products.map(product => (
            <div key={product.id} className="bg-[#11141b] rounded-3xl border border-slate-800 flex flex-col relative overflow-hidden group hover:border-slate-700 transition-colors shadow-lg">
              <div className="p-6">
                <div className="flex justify-between items-start mb-4">
                  <div className="w-12 h-12 bg-indigo-500/10 rounded-2xl flex items-center justify-center border border-indigo-500/20">
                    <Package className="w-6 h-6 text-indigo-400" />
                  </div>
                  <div className="flex gap-2">
                    <button onClick={() => handleEdit(product)} className="p-2 bg-slate-800 hover:bg-slate-700 rounded-lg text-slate-400 hover:text-white transition-colors">
                      <Edit2 className="w-4 h-4" />
                    </button>
                    <button onClick={() => handleDelete(product.id)} className="p-2 bg-red-500/10 hover:bg-red-500/20 rounded-lg text-red-400 transition-colors">
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
                
                <h3 className="text-white font-bold text-lg mb-1">{product.name}</h3>
                
                <div className="flex flex-wrap gap-2 mb-4">
                  {product.category && (
                    <span className="bg-slate-800/80 text-slate-300 text-xs px-2.5 py-1 rounded-md border border-slate-700 flex items-center gap-1.5">
                      <Tag className="w-3 h-3" /> {product.category}
                    </span>
                  )}
                  {product.price !== null && (
                    <span className="bg-emerald-500/10 text-emerald-400 text-xs px-2.5 py-1 rounded-md border border-emerald-500/20 flex items-center gap-1.5">
                      <DollarSign className="w-3 h-3" /> {product.price}
                    </span>
                  )}
                </div>

                <p className="text-slate-400 text-sm mb-4 line-clamp-3 leading-relaxed">{product.description}</p>
                
                <div className="space-y-3 pt-4 border-t border-slate-800/50 mt-auto">
                  {product.targetAudience && (
                    <div className="flex items-start gap-2">
                      <Target className="w-4 h-4 text-slate-500 shrink-0 mt-0.5" />
                      <div>
                        <span className="block text-xs font-bold text-slate-500 mb-0.5">الجمهور المستهدف</span>
                        <span className="text-xs text-slate-300">{product.targetAudience}</span>
                      </div>
                    </div>
                  )}
                  {product.features && (
                    <div className="flex items-start gap-2">
                      <Sparkles className="w-4 h-4 text-slate-500 shrink-0 mt-0.5" />
                      <div>
                        <span className="block text-xs font-bold text-slate-500 mb-0.5">الميزات</span>
                        <span className="text-xs text-slate-300">{product.features}</span>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>
          ))}

          {products.length === 0 && (
            <div className="col-span-full py-16 flex flex-col items-center justify-center text-center border-2 border-dashed border-slate-800 rounded-3xl">
              <div className="w-16 h-16 bg-slate-800 rounded-full flex items-center justify-center mb-4">
                <Package className="w-8 h-8 text-slate-500" />
              </div>
              <h3 className="text-white font-bold text-lg mb-2">لا توجد منتجات بعد</h3>
              <p className="text-slate-400 text-sm max-w-sm mb-6">أضف منتجاتك وخدماتك هنا ليعتمد عليها الذكاء الاصطناعي في كتابة المحتوى وتخطيط الحملات.</p>
              <button 
                onClick={handleAddNew}
                className="bg-blue-600 hover:bg-blue-500 text-white px-6 py-2.5 rounded-xl font-bold text-sm flex items-center gap-2 transition-colors shadow-lg shadow-blue-900/20"
              >
                <Plus className="w-4 h-4" /> إضافة منتج جديد
              </button>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
