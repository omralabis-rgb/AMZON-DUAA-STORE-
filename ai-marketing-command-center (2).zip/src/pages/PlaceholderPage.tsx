export default function PlaceholderPage({ title }: { title: string }) {
  return (
    <div className="flex flex-col h-full">
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-white">{title}</h1>
        <p className="text-slate-500 mt-1 text-sm">هذه الصفحة قيد التطوير في المراحل القادمة.</p>
      </div>
      <div className="flex-1 bg-[#11141b] border border-slate-800 rounded-3xl flex items-center justify-center p-8">
        <div className="text-center">
          <div className="w-16 h-16 bg-blue-600/20 border border-blue-500/20 rounded-full flex items-center justify-center mx-auto mb-4">
            <span className="text-2xl">🚀</span>
          </div>
          <h2 className="text-lg font-bold text-white mb-2">جاري العمل على {title}</h2>
          <p className="text-slate-400 max-w-md mx-auto text-sm leading-relaxed">
            سيتم إضافة ميزات هذه الصفحة بناءً على الخطة المعتمدة في المراحل التالية.
          </p>
        </div>
      </div>
    </div>
  );
}
