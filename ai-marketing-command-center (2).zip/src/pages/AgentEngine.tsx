import { useState, useEffect } from "react";
import { Play, Activity as ActivityIcon, Server, CheckCircle2, AlertCircle, Loader2, Info, Check, RotateCcw, Box, Cpu } from "lucide-react";
import { cn } from "../lib/utils";

// 1. DATA LAYER
type AgentStatus = 'idle' | 'running' | 'error';
type WorkflowStatus = 'idle' | 'running' | 'completed';
type ActivityType = 'info' | 'success' | 'warning' | 'error';

interface Agent {
  id: string;
  name: string;
  status: AgentStatus;
  role: string;
}

interface Workflow {
  id: string;
  name: string;
  description: string;
  status: WorkflowStatus;
  progress: number;
}

interface Activity {
  id: string;
  timestamp: string;
  message: string;
  type: ActivityType;
}

const DEFAULT_AGENTS: Agent[] = [
  { id: '1', name: 'مستشار التسويق', role: 'تخطيط الحملات', status: 'idle' },
  { id: '2', name: 'مستشار المحتوى', role: 'توليد النصوص', status: 'idle' },
  { id: '3', name: 'مستشار DevOps', role: 'استقرار النظام', status: 'idle' },
];

const DEFAULT_WORKFLOWS: Workflow[] = [
  { id: 'w1', name: 'إطلاق حملة تسويقية شاملة', description: 'تحليل المنافسين، كتابة المحتوى، وجدولة النشر.', status: 'idle', progress: 0 },
  { id: 'w2', name: 'تحليل أداء النظام الشامل', description: 'فحص الـ Logs واكتشاف الاختناقات البرمجية.', status: 'idle', progress: 0 },
  { id: 'w3', name: 'صناعة محتوى أسبوعي', description: 'إنتاج 5 منشورات لمنصات التواصل مع الصور.', status: 'idle', progress: 0 },
];

export default function AgentEngine() {
  const [agents, setAgents] = useState<Agent[]>(DEFAULT_AGENTS);
  const [workflows, setWorkflows] = useState<Workflow[]>(DEFAULT_WORKFLOWS);
  const [activities, setActivities] = useState<Activity[]>([]);
  const [stats, setStats] = useState({ totalRuns: 0, successRate: 100, activeTasks: 0 });
  const [toast, setToast] = useState<{ message: string, visible: boolean } | null>(null);

  // loadState
  useEffect(() => {
    const saved = localStorage.getItem('agent_engine_state');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        setAgents(parsed.agents || DEFAULT_AGENTS);
        setWorkflows(parsed.workflows || DEFAULT_WORKFLOWS);
        setActivities(parsed.activities || []);
        setStats(parsed.stats || { totalRuns: 0, successRate: 100, activeTasks: 0 });
      } catch (e) {
        console.error("Failed to parse state", e);
      }
    } else {
      addActivity("تم تشغيل محرك الوكلاء (Agent Engine)", "info");
    }
  }, []);

  // saveState
  useEffect(() => {
    localStorage.setItem('agent_engine_state', JSON.stringify({ agents, workflows, activities, stats }));
  }, [agents, workflows, activities, stats]);

  // 3. ACTIONS LAYER
  const showToast = (message: string) => {
    setToast({ message, visible: true });
    setTimeout(() => setToast(null), 3000);
  };

  const addActivity = (message: string, type: ActivityType = 'info') => {
    const newActivity: Activity = {
      id: Math.random().toString(36).substring(7),
      timestamp: new Date().toLocaleTimeString('ar-SA'),
      message,
      type
    };
    setActivities(prev => [newActivity, ...prev].slice(0, 50));
  };

  const resetState = () => {
    if (!confirm("هل أنت متأكد من إعادة ضبط المحرك وتفريغ البيانات؟")) return;
    setAgents(DEFAULT_AGENTS);
    setWorkflows(DEFAULT_WORKFLOWS);
    setActivities([]);
    setStats({ totalRuns: 0, successRate: 100, activeTasks: 0 });
    addActivity("تم إعادة ضبط النظام بنجاح", "warning");
    showToast("تم إعادة الضبط");
  };

  const runWorkflow = async (workflowId: string) => {
    const workflow = workflows.find(w => w.id === workflowId);
    if (!workflow || workflow.status === 'running') return;

    setWorkflows(prev => prev.map(w => w.id === workflowId ? { ...w, status: 'running', progress: 0 } : w));
    setStats(prev => ({ ...prev, activeTasks: prev.activeTasks + 1 }));
    addActivity(`بدء تنفيذ مسار العمل: [${workflow.name}]`, 'info');
    
    // Randomly select agents to run
    setAgents(prev => prev.map(a => Math.random() > 0.3 ? { ...a, status: 'running' } : a));

    // Simulation Engine
    const steps = 10;
    for (let i = 1; i <= steps; i++) {
      await new Promise(r => setTimeout(r, 600)); // 600ms per step
      setWorkflows(prev => prev.map(w => w.id === workflowId ? { ...w, progress: i * 10 } : w));
      
      if (i === 3) addActivity(`[${workflow.name}] جاري تجميع البيانات وتحليل السياق...`, 'info');
      if (i === 6) addActivity(`[${workflow.name}] يتم معالجة المخرجات بواسطة الوكلاء...`, 'warning');
      if (i === 9) addActivity(`[${workflow.name}] التحضير للإنهاء وحفظ النتائج...`, 'info');
    }

    setWorkflows(prev => prev.map(w => w.id === workflowId ? { ...w, status: 'completed', progress: 100 } : w));
    setAgents(prev => prev.map(a => ({ ...a, status: 'idle' })));
    setStats(prev => ({ 
      ...prev, 
      totalRuns: prev.totalRuns + 1,
      activeTasks: Math.max(0, prev.activeTasks - 1)
    }));
    addActivity(`اكتمل مسار العمل: [${workflow.name}] بنجاح!`, 'success');
    showToast('تم اكتمال المهمة بنجاح');
  };

  // 2. RENDERING LAYER
  const renderStats = () => (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
      <div className="bg-[#11141b] rounded-3xl border border-slate-800 p-6 flex items-center gap-4 shadow-lg">
        <div className="w-14 h-14 rounded-2xl bg-blue-500/10 flex items-center justify-center border border-blue-500/20">
          <Play className="w-6 h-6 text-blue-400" />
        </div>
        <div>
          <p className="text-slate-400 text-sm font-bold mb-1">إجمالي العمليات</p>
          <h3 className="text-2xl font-black text-white">{stats.totalRuns}</h3>
        </div>
      </div>
      <div className="bg-[#11141b] rounded-3xl border border-slate-800 p-6 flex items-center gap-4 shadow-lg">
        <div className="w-14 h-14 rounded-2xl bg-emerald-500/10 flex items-center justify-center border border-emerald-500/20">
          <CheckCircle2 className="w-6 h-6 text-emerald-400" />
        </div>
        <div>
          <p className="text-slate-400 text-sm font-bold mb-1">معدل النجاح</p>
          <h3 className="text-2xl font-black text-white">{stats.successRate}%</h3>
        </div>
      </div>
      <div className="bg-[#11141b] rounded-3xl border border-slate-800 p-6 flex items-center gap-4 shadow-lg">
        <div className="w-14 h-14 rounded-2xl bg-amber-500/10 flex items-center justify-center border border-amber-500/20">
          <ActivityIcon className="w-6 h-6 text-amber-400" />
        </div>
        <div>
          <p className="text-slate-400 text-sm font-bold mb-1">المهام النشطة</p>
          <h3 className="text-2xl font-black text-white">{stats.activeTasks}</h3>
        </div>
      </div>
    </div>
  );

  const renderAgents = () => (
    <div className="bg-[#11141b] rounded-3xl border border-slate-800 p-6 shadow-xl h-full flex flex-col">
      <div className="flex items-center gap-3 mb-6">
        <div className="w-10 h-10 rounded-xl bg-indigo-500/10 flex items-center justify-center border border-indigo-500/20">
          <Cpu className="w-5 h-5 text-indigo-400" />
        </div>
        <h2 className="text-lg font-bold text-white">الوكلاء النشطون (Agents)</h2>
      </div>
      <div className="space-y-4 flex-1 overflow-y-auto custom-scrollbar pr-2">
        {agents.map(agent => (
          <div key={agent.id} className="bg-[#161a23] rounded-2xl p-4 border border-slate-700/50 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-slate-800 flex items-center justify-center border border-slate-700">
                <Server className="w-4 h-4 text-slate-400" />
              </div>
              <div>
                <h4 className="text-sm font-bold text-white mb-0.5">{agent.name}</h4>
                <p className="text-xs text-slate-400">{agent.role}</p>
              </div>
            </div>
            <div className={cn(
              "px-3 py-1.5 rounded-lg text-xs font-bold flex items-center gap-2",
              agent.status === 'running' ? "bg-amber-500/10 text-amber-400 border border-amber-500/20" : 
              agent.status === 'error' ? "bg-red-500/10 text-red-400 border border-red-500/20" : 
              "bg-emerald-500/10 text-emerald-400 border border-emerald-500/20"
            )}>
              {agent.status === 'running' && <Loader2 className="w-3 h-3 animate-spin" />}
              {agent.status === 'running' ? 'نشط ويعمل' : 'متاح (Idle)'}
            </div>
          </div>
        ))}
      </div>
    </div>
  );

  const renderWorkflows = () => (
    <div className="bg-[#11141b] rounded-3xl border border-slate-800 p-6 shadow-xl h-full flex flex-col">
      <div className="flex items-center gap-3 mb-6">
        <div className="w-10 h-10 rounded-xl bg-pink-500/10 flex items-center justify-center border border-pink-500/20">
          <Box className="w-5 h-5 text-pink-400" />
        </div>
        <h2 className="text-lg font-bold text-white">مسارات العمل (Workflows)</h2>
      </div>
      <div className="space-y-4 flex-1 overflow-y-auto custom-scrollbar pr-2">
        {workflows.map(wf => (
          <div key={wf.id} className="bg-[#161a23] rounded-2xl p-5 border border-slate-700/50 relative overflow-hidden group">
            {/* Progress bar background */}
            {wf.status === 'running' && (
              <div className="absolute inset-0 bg-blue-500/5 transition-all duration-300" style={{ width: `${wf.progress}%` }} />
            )}
            
            <div className="relative z-10 flex justify-between items-start mb-4">
              <div>
                <h4 className="text-base font-bold text-white mb-1">{wf.name}</h4>
                <p className="text-xs text-slate-400 line-clamp-2 leading-relaxed">{wf.description}</p>
              </div>
              <button 
                onClick={() => runWorkflow(wf.id)}
                disabled={wf.status === 'running'}
                className="shrink-0 bg-blue-600 hover:bg-blue-500 disabled:bg-slate-700 disabled:text-slate-500 text-white w-10 h-10 rounded-xl flex items-center justify-center transition-colors shadow-lg shadow-blue-900/20 disabled:shadow-none"
              >
                {wf.status === 'running' ? <Loader2 className="w-4 h-4 animate-spin" /> : <Play className="w-4 h-4 fill-current" />}
              </button>
            </div>

            {wf.status === 'running' && (
              <div className="relative z-10">
                <div className="flex justify-between text-xs font-bold mb-2">
                  <span className="text-blue-400">جاري التنفيذ...</span>
                  <span className="text-slate-400">{wf.progress}%</span>
                </div>
                <div className="h-2 w-full bg-slate-800 rounded-full overflow-hidden">
                  <div className="h-full bg-blue-500 transition-all duration-300 rounded-full" style={{ width: `${wf.progress}%` }} />
                </div>
              </div>
            )}
            
            {wf.status === 'completed' && (
              <div className="relative z-10 flex items-center gap-2 text-emerald-400 text-xs font-bold mt-2">
                <CheckCircle2 className="w-4 h-4" /> اكتملت المهمة
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );

  const renderActivities = () => (
    <div className="bg-[#11141b] rounded-3xl border border-slate-800 p-6 shadow-xl h-full flex flex-col">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-slate-800 flex items-center justify-center border border-slate-700">
            <ActivityIcon className="w-5 h-5 text-slate-400" />
          </div>
          <h2 className="text-lg font-bold text-white">سجل العمليات (Activity Log)</h2>
        </div>
        <button onClick={resetState} className="text-slate-500 hover:text-red-400 transition-colors p-2 rounded-lg hover:bg-red-500/10">
          <RotateCcw className="w-4 h-4" />
        </button>
      </div>
      
      <div className="flex-1 bg-[#0a0c10] rounded-2xl border border-slate-800/50 p-4 overflow-y-auto custom-scrollbar font-mono text-sm space-y-3">
        {activities.length === 0 ? (
          <div className="text-slate-500 text-center py-10">لا توجد عمليات مسجلة</div>
        ) : (
          activities.map((act) => {
            const Icon = act.type === 'success' ? Check : act.type === 'warning' ? AlertCircle : act.type === 'error' ? AlertCircle : Info;
            const colorClass = 
              act.type === 'success' ? 'text-emerald-400' : 
              act.type === 'warning' ? 'text-amber-400' : 
              act.type === 'error' ? 'text-red-400' : 'text-blue-400';
            
            return (
              <div key={act.id} className="flex gap-3 items-start animate-in fade-in slide-in-from-bottom-2">
                <span className="text-slate-600 shrink-0 text-xs mt-0.5">[{act.timestamp}]</span>
                <Icon className={cn("w-4 h-4 shrink-0 mt-0.5", colorClass)} />
                <span className={cn("text-slate-300 leading-relaxed", colorClass)}>{act.message}</span>
              </div>
            );
          })
        )}
      </div>
    </div>
  );

  // 4. EVENT BINDINGS (handled inline within JSX via onClick, etc.)
  return (
    <div className="space-y-6 h-full flex flex-col max-w-7xl mx-auto w-full">
      {toast && (
        <div className="fixed bottom-6 right-6 bg-emerald-500 text-white px-6 py-3 rounded-2xl shadow-xl shadow-emerald-500/20 font-bold text-sm flex items-center gap-3 z-50 animate-in fade-in slide-in-from-bottom-4">
          <CheckCircle2 className="w-5 h-5" />
          {toast.message}
        </div>
      )}

      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-2">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 bg-blue-600/20 rounded-xl flex items-center justify-center border border-blue-500/20">
            <Cpu className="w-6 h-6 text-blue-400" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-white mb-1">محرك الوكلاء (Agent Engine)</h1>
            <p className="text-slate-400 text-sm">بيئة محاكاة مستقلة لترتيب وتنفيذ مسارات العمل بواسطة الذكاء الاصطناعي.</p>
          </div>
        </div>
      </div>

      {renderStats()}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 flex-1 min-h-[500px]">
        <div className="lg:col-span-1 flex flex-col gap-6">
          {renderAgents()}
        </div>
        <div className="lg:col-span-1">
          {renderWorkflows()}
        </div>
        <div className="lg:col-span-1">
          {renderActivities()}
        </div>
      </div>
    </div>
  );
}
