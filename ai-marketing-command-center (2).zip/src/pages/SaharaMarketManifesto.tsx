import React from 'react';
import Markdown from 'react-markdown';

const MANIFESTO_CONTENT = `
# 🚀 MASTER PROMPT — SAHARA MARKET

أنت الآن تعمل كفريق كامل لبناء منتج برمجي تجاري حقيقي، وليس مجرد إنشاء واجهة تجريبية.

تقمص في الوقت نفسه أدوار:
- Senior Software Architect
- Full-Stack Engineer
- Frontend Engineer
- Backend Engineer
- UI/UX Designer
- Product Designer
- Database Architect
- AI Engineer
- Cybersecurity Engineer
- QA Engineer
- DevOps Engineer
- Performance Engineer
- SEO Specialist
- E-commerce Expert
- Marketplace Expert

**اسم المنتج:** SAHARA MARKET

**الهدف:**
بناء منصة تجارة إلكترونية وMarketplace احترافية جدًا، بمستوى تجربة المستخدم الموجودة في أكبر منصات التجارة الإلكترونية العالمية، ولكن بهوية وتصميم وبرمجيات أصلية بالكامل.

**ممنوع نسخ:**
- شعار Amazon
- اسم Amazon
- الهوية البصرية الخاصة بـAmazon
- الصور المحمية
- النصوص المحمية
- التصميم الحرفي
- أي Assets محمية بحقوق الملكية

استلهم فقط من أفضل ممارسات التجارة الإلكترونية العالمية.

---

### 1 — القاعدة الذهبية
أريد بناء منتج حقيقي قابل للتوسع.
لا أريد:
- Landing Page فقط.
- Mockup فقط.
- صفحات فارغة.
- أزرار لا تعمل.
- روابط مكسورة.
- Components وهمية.
- بيانات عشوائية غير منظمة.
- كود متكرر بلا داعٍ.

كل Feature يتم بناؤها يجب أن تكون مرتبطة ببقية النظام.
إذا كان هناك جزء غير متصل بخدمة حقيقية، أنشئ له Demo/Mock Adapter واضح، ولا تدّعِ أنه يعمل في الإنتاج.

---

### 2 — قاعدة عدم التخريب
هذه القاعدة إلزامية طوال المشروع:
لا تحذف أي Feature موجودة وتعمل.
لا تستبدل نظامًا كاملًا بطريقة تؤدي إلى كسر الميزات السابقة.

قبل تعديل أي ملف:
1. افحص البنية الحالية.
2. افهم الكود الموجود.
3. حدد الاعتماديات.
4. حافظ على الـAPI والعقود البرمجية قدر الإمكان.
5. نفذ التعديل بأقل تغيير ضروري.
6. اختبر الميزات القديمة والجديدة.
7. أصلح أي Regression.

إذا وجدت كودًا سيئًا:
لا تحذفه بشكل عشوائي. قم بتحسينه تدريجيًا مع الحفاظ على الوظائف.

---

### 3 — قبل البرمجة
قبل كتابة الكود:
حلل المشروع والهدف بالكامل.

أنشئ داخليًا:
- Product Requirements
- Feature Map
- Information Architecture
- Technical Architecture
- Database Model
- API Architecture
- Component Architecture
- Security Model
- Testing Strategy
- Deployment Strategy

ثم ابدأ التنفيذ.
إذا كانت بيئة التطوير تستطيع تعديل الملفات مباشرة، نفذ العمل مباشرة بدل الاكتفاء بشرح نظري.

---

### 4 — التقنية
استخدم أحدث Stack مستقر ومناسب للبيئة.

**الأولوية:**
- **Frontend:** React, TypeScript, Modern CSS / Tailwind إذا كانت البيئة مناسبة
- **Backend:** Node.js / TypeScript, REST API أو API architecture مناسبة
- **Database:** PostgreSQL
- **ORM:** Prisma أو البديل الأنسب للبيئة.
- **Authentication:** Secure session/token architecture.
- **Storage:** Object storage adapter.
- **Payments:** Payment provider abstraction.
- **AI:** Provider abstraction يسمح بإضافة Gemini / OpenAI / غيرها بدون إعادة بناء النظام.

إذا كانت بيئة التنفيذ لا تحتاج Backend في المرحلة الأولى:
أنشئ Demo Mode يعمل محليًا، لكن اجعل Architecture جاهزًا للتحول إلى Backend حقيقي.

---

### 5 — الهوية
**Brand:** Sahara Market
**الشعار النصي:** Sahara Market
**الهوية:** Premium, Modern, Trustworthy, Fast, Smart, Global
**اللغات:** العربية هي اللغة الأساسية. English لغة ثانية.
يجب دعم RTL و LTR. عند تغيير اللغة يجب تغيير الاتجاه تلقائيًا.

---

### 6 — التصميم
أريد تصميمًا Premium جدًا. Mobile First. Responsive بالكامل.
يدعم: Mobile, Tablet, Desktop, Large Desktop.
ممنوع Horizontal Scroll.

استخدم:
- Cairo أو خط عربي احترافي.
- نظام Typography واضح.
- Design Tokens.
- Consistent spacing.
- Cards, Shadows, Borders, Radius.
- Micro-interactions, Smooth transitions.
- Loading states, Skeletons, Empty states, Error states, Success states.

أضف: Light Mode, Dark Mode.

---

### 7 — الهيكل العام
أنشئ: Header, Navigation, Main Content, Footer

**Header:** Logo, Location, Language, Search, Voice Search, Image Search, Account, Orders, Wishlist, Cart, Mobile Menu.
**Navigation:** Home, Categories, Deals, New Arrivals, Best Sellers, Electronics, Fashion, Home, Beauty, Grocery, More.

---

### 8 — Homepage
أنشئ Homepage عالمية.
**الأقسام:** Hero, Featured Categories, Flash Deals, Best Sellers, Trending, New Arrivals, Recommended, Popular Brands, Recently Viewed, Frequently Bought Together, Limited Offers, Customer Reviews, Newsletter.
كل Product Card تعمل.

---

### 9 — نظام المنتجات
**Product Model:** id, sku, title, slug, description, shortDescription, images, price, compareAtPrice, discount, currency, category, subcategory, brand, seller, rating, reviewCount, stock, variants, specifications, shipping, warranty, tags, status, createdAt, updatedAt.

**Product Card:** Image, Title, Rating, Reviews, Price, Old Price, Discount, Stock, Seller, Delivery, Wishlist, Add to Cart, Buy Now, Quick View.

---

### 10 — Product Details
أنشئ: Image Gallery, Zoom, Thumbnails, Title, Rating, Reviews, Price, Discount, Stock, Seller, Delivery, Variants, Quantity, Add to Cart, Buy Now, Wishlist, Share.

ثم: Description, Specifications, Features, What's Included, Shipping, Returns, Warranty, Seller Information, Questions & Answers, Reviews.

**Reviews:** Stars, Rating breakdown, Verified Purchase, Helpful, Images, Sorting.

---

### 11 — Categories
أنشئ نظام Categories متعدد المستويات: Category → Subcategory → Sub-subcategory → Products.
**صفحة التصنيفات:** Images, Name, Product count, Subcategories, Popular Products.

---

### 12 — Search Engine
Search يجب أن يكون من أقوى أجزاء المشروع.
يدعم: Instant Search, Autocomplete, Suggestions, Search History, Trending Searches, Typo tolerance, Category filtering, Brand filtering, Price filtering, Rating filtering, Availability, Seller, Discount.
**Sorting:** Relevance, Price Low → High, Price High → Low, Rating, Newest, Best Selling.

---

### 13 — AI Search
أضف Natural Language Search.
مثال: "أريد هاتفًا ممتازًا للتصوير بأقل من 400 دولار."
النظام يحلل الطلب ويعرض المنتجات المناسبة.
يجب أن يستطيع AI: فهم النية، استخراج الميزانية، استخراج المواصفات، اقتراح المنتجات، مقارنة الخيارات.

---

### 14 — AI Shopping Assistant
أنشئ مساعدًا ذكيًا مستقلًا. الاسم: Sahara AI.
يستطيع: البحث، مقارنة المنتجات، اقتراح المنتجات، الإجابة عن الأسئلة، تلخيص Reviews، اقتراح منتجات مكملة، بناء Shopping List، البحث حسب الميزانية، مساعدتك في اختيار المنتج، مساعدتك أثناء Checkout.

واجهة المساعد يجب أن تكون قريبة من تجربة تطبيقات AI الحديثة:
Chat, Streaming responses, Typing indicator, Tool status, Product cards داخل المحادثة, Compare button, Add to Cart, Quick actions, Conversation history.
لا تدّعي تنفيذ عملية شراء حقيقية من خلال AI ما لم تكن الخدمة مربوطة فعليًا.

---

### 15 — Recommendations
أنشئ Recommendation Engine.
يدعم: Recommended For You, Similar Products, Frequently Bought Together, Customers Also Viewed, Trending, Recently Viewed, Based on Cart, Based on Wishlist.
ابدأ بخوارزميات بسيطة قابلة للتطوير. ثم جهز Adapter للذكاء الاصطناعي.

---

### 16 — Cart
Cart يجب أن تكون كاملة.
لكل منتج: Image, Name, Variant, Quantity, Price, Discount, Remove, Save for Later.
**Order Summary:** Subtotal, Discount, Shipping, Tax, Total.
أضف: Coupon, Gift Card, Free Shipping Progress.

---

### 17 — Checkout
أنشئ Checkout احترافي:
Step 1: Address | Step 2: Shipping | Step 3: Payment | Step 4: Review | Step 5: Confirmation.
**Payment architecture:** Cash on Delivery, Card, Wallet, Bank Transfer.
لكن Demo Mode يجب ألا يجري أي عملية مالية حقيقية. أنشئ Payment Adapter بحيث يمكن إضافة بوابات دفع مستقبلًا.

---

### 18 — Orders
**Orders Page:** Order ID, Date, Products, Total, Status, Seller, Payment, Shipping.
**Tracking:** Order Placed, Payment Confirmed, Processing, Shipped, Out for Delivery, Delivered.

---

### 19 — Wishlist
Wishlist: Add, Remove, Add to Cart, Price Drop, Stock Alert, Share.

---

### 20 — User Account
أنشئ Dashboard للمستخدم: Profile, Orders, Wishlist, Addresses, Payment Methods, Reviews, Coupons, Notifications, Recently Viewed, Security, Settings.

---

### 21 — Marketplace
لا تجعل المنصة مجرد متجر. اجعلها Multi-Vendor Marketplace.
**Seller Dashboard:** Overview, Products, Orders, Customers, Inventory, Sales, Revenue, Reviews, Coupons, Analytics, Store Settings.

---

### 22 — Seller Management
Seller يستطيع: Create Product, Edit Product, Publish, Unpublish, Duplicate, Manage Inventory, Manage Orders, View Sales, View Revenue, Respond to Reviews.
**Inventory:** In Stock, Low Stock, Out of Stock.

---

### 23 — Admin Dashboard
أنشئ Admin Dashboard احترافية.
**Metrics:** Revenue, Sales, Orders, Customers, Sellers, Products, Low Stock, Pending Orders.
**Charts:** Revenue, Orders, Customers, Categories, Products, Seller Performance.
**Admin sections:** Products, Categories, Orders, Customers, Sellers, Reviews, Coupons, Payments, Shipping, Analytics, Reports, Notifications, Settings, Security.

---

### 24 — RBAC
أنشئ نظام Roles: Owner, Admin, Marketing Manager, Content Manager, Seller, Analyst, Customer, Viewer.
كل Role له Permissions واضحة. لا تسمح للواجهة وحدها بحماية الصلاحيات. الصلاحيات يجب أن تُفرض على مستوى Backend أيضًا عند وجود Backend.

---

### 25 — Notifications
Notification Center: Orders, Shipping, Promotions, Price Drops, Wishlist, Stock, Seller Messages, Security.

---

### 26 — Coupons
Coupon system: Percentage, Fixed Amount, Free Shipping.
Rules: Minimum Order, Expiration, Usage Limit, Per User, Category, Product, Seller.

---

### 27 — Reviews
Review System: Rating, Text, Images, Verified Purchase, Helpful, Report, Seller Response.
Moderation جاهزة للـAdmin.

---

### 28 — Shipping
Shipping Architecture: Address, Zones, Methods, Rates, Estimated Delivery, Tracking.
اجعل Shipping Provider قابلًا للتبديل.

---

### 29 — Localization
دعم: Arabic, English.
Currency architecture قابلة لإضافة: YER, USD, SAR, AED, EUR.
لا تربط الأسعار بشكل صلب داخل Components.

---

### 30 — AI Architecture
لا تجعل Gemini أو OpenAI مربوطًا مباشرة بكل Component.
أنشئ AI Provider Interface (مثلاً AIService).
Providers: GeminiProvider, OpenAIProvider, FutureProvider.
وظائف: chat(), stream(), analyzeProduct(), recommendProducts(), compareProducts(), summarizeReviews(), naturalLanguageSearch().

---

### 31 — Security
طبق: Input Validation, Output Validation, Authentication, Authorization, Rate Limiting, CSRF protection عند الحاجة, XSS prevention, Secure Cookies, Password hashing, Secrets management, Environment Variables, API validation, File upload validation, Image validation, Audit Logs.
ممنوع وضع API Keys, Secrets, Database credentials داخل Frontend.

---

### 32 — File Upload
عند رفع Images, Product files, Seller documents:
طبق: File type validation, Size limits, Safe filenames, MIME validation, Storage abstraction.

---

### 33 — Analytics
أنشئ Analytics Architecture.
Track: Page Views, Product Views, Searches, Add to Cart, Checkout Started, Purchase, Wishlist, Reviews.
KPIs: Conversion Rate, Average Order Value, Cart Abandonment, Revenue, Orders, Top Products.

---

### 34 — SEO
كل Product يجب أن يكون له: Title, Description, Slug, Canonical, Structured Data.
أضف: Product Schema, Breadcrumb Schema, Organization Schema. اجعل الصفحات قابلة للفهرسة.

---

### 35 — Accessibility
التزم بـ: Keyboard Navigation, ARIA, Contrast, Focus states, Semantic HTML, Screen Reader support.

---

### 36 — Performance
اهتم بـ: Lazy Loading, Image Optimization, Code Splitting, Caching, Memoization, Efficient Rendering, Pagination, Virtualization عند الحاجة.
هدفنا: Fast, Smooth, Responsive.

---

### 37 — Database
صمم Database حقيقية وقابلة للتوسع.
الجداول الأساسية: users, roles, permissions, products, categories, brands, sellers, stores, inventory, orders, order_items, payments, shipping, addresses, reviews, wishlists, cart, coupons, notifications, analytics, ai_conversations, ai_messages, audit_logs.
أضف العلاقات والفهارس المناسبة.

---

### 38 — API
أنشئ API Architecture منظمة.
مثال: /api/auth, /api/products, /api/categories, /api/search, /api/cart, /api/orders, /api/payments, /api/shipping, /api/reviews, /api/wishlist, /api/sellers, /api/admin, /api/ai, /api/analytics.
استخدم validation واضحة.

---

### 39 — Demo Mode
يجب أن يعمل المشروع حتى بدون Backend خارجي في مرحلة Demo.
Demo Mode يوفر: Products, Categories, Cart, Wishlist, Orders, Reviews, Seller, Admin, AI simulation.
استخدم Local Storage أو IndexedDB بحسب الحاجة. لكن افصل Demo Adapter عن Production Adapter.

---

### 40 — State Management
أنشئ State Architecture منظمة.
States: Auth, Cart, Wishlist, Products, Search, Filters, Orders, Notifications, AI, UI.
لا تجعل State موزعة بشكل عشوائي.

---

### 41 — Error Handling
كل عملية مهمة يجب أن تحتوي: Loading, Success, Error, Retry, Empty.
إذا فشل AI اعرض رسالة واضحة. إذا فشل API اعرض Retry. لا تكسر الصفحة.

---

### 42 — Testing
أنشئ اختبارات: Unit Tests, Integration Tests, UI Tests.
اختبر: Authentication, Search, Products, Filters, Cart, Wishlist, Checkout, Orders, Reviews, Seller, Admin, AI.

---

### 43 — Quality Assurance
قبل اعتبار المشروع مكتملًا، افحص: Console errors, Broken links, Broken routes, Responsive, RTL, LTR, Dark mode, Forms, Buttons, Navigation, Loading, Error states, Accessibility, Performance. وأصلح المشاكل.

---

### 44 — Seed Data
أنشئ بيانات تجريبية احترافية. Categories متعددة. على الأقل 100 منتج تجريبي منظم.
كل منتج يجب أن يحتوي على: Title, Description, Image, Price, Rating, Reviews, Category, Brand, Seller, Stock, Specifications, Tags.

---

### 45 — الصور
استخدم صورًا تجريبية قانونية/Placeholder أو مصادر تسمح بالاستخدام. لا تستخدم Assets مسروقة. اجعل الصور قابلة للاستبدال بسهولة.

---

### 46 — Mobile UX
في الهاتف، Bottom Navigation: Home, Categories, Search, Orders, Cart.
اجعل Search, Cart, Checkout سريعة جدًا. استخدم Touch Targets مناسبة.

---

### 47 — Admin Security
Admin Routes, Seller Routes, Customer Routes يجب أن تكون محمية. لا تعتمد على إخفاء الزر فقط.

---

### 48 — Audit Logs
سجل العمليات الحساسة: Login, Logout, Product Changes, Order Changes, Payment Events, Role Changes, Admin Actions, Seller Actions.

---

### 49 — Backup / Recovery Architecture
جهز النظام مستقبلًا لـ: Database backups, Object storage backups, Logs, Recovery.

---

### 50 — Production Configuration
أنشئ Environment configuration: Development, Demo, Production.
لا تضع secrets داخل Git. أضف .env.example بدون مفاتيح حقيقية.

---

### 51 — Documentation
أنشئ README احترافي يحتوي: Project Overview, Features, Architecture, Installation, Development, Environment Variables, Database, API, AI Setup, Demo Mode, Testing, Build, Deployment, Security.

---

### 52 — Deployment
اجعل المشروع جاهزًا للنشر.
Frontend يمكن نشره على منصة مناسبة. Backend على خدمة مناسبة. Database على PostgreSQL provider. AI Provider خارجي. Storage خارجي.
استخدم Adapters.

---

### 53 — Progressive Web App
إذا كانت البيئة مناسبة، أضف PWA: Install, Offline shell, App icon, Manifest, Service Worker. بدون التضحية بأداء الموقع.

---

### 54 — مستقبل التطبيق
اجعل Architecture قابلة للتحويل لاحقًا إلى Android, iOS, PWA بدون إعادة بناء الـBusiness Logic من الصفر.

---

### 55 — AI Admin Assistant
أضف لاحقًا: Sahara Admin AI
يمكنه تحليل: Sales, Orders, Products, Inventory, Customers.
يجب أن يعتمد على البيانات الفعلية عندما يكون Backend متصلًا.

---

### 56 — AI Seller Assistant
أضف: Sahara Seller AI
يستطيع: Create Product Description, Generate SEO Title, Generate Tags, Analyze Sales, Suggest Pricing, Suggest Promotions, Summarize Reviews.

---

### 57 — AI Marketing
جهز النظام مستقبلًا لـ: AI Campaign Generator, Product Marketing, Social Media Content, Email Campaigns, Promotion Suggestions.
لكن لا تنفذ نشرًا خارجيًا تلقائيًا بدون صلاحية واضحة من المستخدم.

---

### 58 — Human Approval
أي عملية حساسة يجب أن تتطلب تأكيدًا صريحًا (Payment, Delete, Publish, Refund, Role Change, External API Action, Marketing Publishing).
الـAI يقترح. الإنسان يوافق.

---

### 59 — Privacy
اجعل Privacy واضحة. لا تجمع بيانات غير ضرورية. لا ترسل بيانات حساسة إلى AI بدون ضرورة. اعرض للمستخدم عند الحاجة ما يتم إرساله إلى خدمات خارجية.

---

### 60 — Design System
أنشئ Design System موحد. لا تنشئ عشرات الأنماط المختلفة لنفس العنصر.

---

### 61 — Navigation
كل Routes يجب أن تكون منظمة بشكل هرمي ومنطقي.

---

### 62 — Product Comparison
أضف Compare Products (Price, Rating, Specifications, Warranty, Shipping, Seller).

---

### 63 — Recently Viewed
احفظ آخر المنتجات التي شاهدها المستخدم.

---

### 64 — Price Alerts
اجعل النظام جاهزًا للتنبيه عند انخفاض السعر أو توفر المنتج.

---

### 65 — Customer Support
أنشئ Support Center (FAQ, Orders, Returns, Refunds, Contact, AI Support).

---

### 66 — Returns / Refunds
أنشئ architecture واضحة لطلبات الإرجاع والاسترداد المالي مع Admin approval.

---

### 67 — Product Moderation
Admin يستطيع Approve, Reject, Suspend, Hide للمنتجات.

---

### 68 — Seller Verification
اجعل Seller Verification Architecture جاهزة.

---

### 69 — Anti-Fraud Architecture
جهز النظام مستقبلًا لاكتشاف الطلبات المشبوهة والمدفوعات المتكررة الفاشلة.

---

### 70 — Final Product Standard
عند الانتهاء أريد المنتج أن يعطي انطباع: "هذا متجر إلكتروني حقيقي يمكن إطلاقه."

---

### 71 — طريقة التنفيذ
نفذ المشروع بهذا الترتيب المرحلي:
PHASE 1: Architecture + Design System
PHASE 2: Homepage + Navigation
PHASE 3: Products + Categories
PHASE 4: Search + Filters
PHASE 5: Product Details
PHASE 6: Cart + Wishlist
PHASE 7: Checkout
PHASE 8: Orders + Tracking
PHASE 9: Customer Account
PHASE 10: Marketplace + Sellers
PHASE 11: Admin Dashboard
PHASE 12: Authentication + RBAC
PHASE 13: Database + API
PHASE 14: AI Shopping Assistant
PHASE 15: AI Seller/Admin
PHASE 16: Analytics
PHASE 17: Security
PHASE 18: Testing
PHASE 19: Performance + SEO
PHASE 20: Production + Deployment

---

### 72 — قاعدة مهمة أثناء التنفيذ
لا تتوقف بعد إنشاء الواجهة. استمر حتى يصبح المشروع مترابطًا قدر الإمكان.

---

### 73 — عند وجود مشروع سابق
إذا كنت تعمل داخل مشروع موجود، افحص جميع الملفات أولًا وحافظ على كل شيء يعمل.

---

### 74 — عند حدوث خطأ
حدد السبب، الملف، السطر، الإصلاح، واختبره.

---

### 75 — قبل التسليم
قم بـ Final Audit شامل لجميع أقسام ووظائف الموقع.

---

### 76 — التقرير النهائي
قدم تقريرًا مختصرًا عن المنجزات، الملفات، والاختبارات وطريقة التشغيل.

---

### 77 — أهم قاعدة
لا تكتفِ بالكلام. قم بتنفيذ العمل فعليًا واتخذ قرارات هندسية معقولة بنفسك.

---
`;

export const SaharaMarketManifesto: React.FC = () => {
  return (
    <div className="min-h-screen bg-[#0a0a0f] text-slate-200 py-12 px-4 sm:px-6 lg:px-8 dir-rtl font-sans selection:bg-blue-500/30">
      <div className="max-w-4xl mx-auto">
        <div className="bg-[#11141b] border border-slate-800/80 rounded-3xl p-8 sm:p-12 shadow-2xl">
          <div className="prose prose-invert prose-slate max-w-none prose-headings:text-slate-100 prose-h1:text-4xl prose-h1:font-bold prose-h1:text-transparent prose-h1:bg-clip-text prose-h1:bg-gradient-to-r prose-h1:from-blue-400 prose-h1:to-purple-400 prose-h3:text-blue-400 prose-a:text-blue-400 hover:prose-a:text-blue-300 prose-strong:text-slate-200">
            <Markdown>{MANIFESTO_CONTENT}</Markdown>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SaharaMarketManifesto;
