import { 
  TrendingUp, 
  Users, 
  Target, 
  CheckCircle2, 
  Clock, 
  AlertCircle,
  Megaphone
} from "lucide-react";

export default function Dashboard() {
  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-2">
        <div>
          <h1 className="text-2xl font-bold text-white">نظرة عامة</h1>
          <p className="text-slate-500 mt-1 text-sm">إليك نظرة سريعة على أداء وكيل التسويق الذكي اليوم.</p>
        </div>
        <div className="flex items-center gap-4 bg-[#11141b] p-1.5 rounded-2xl border border-slate-800">
          <div className="hidden sm:flex items-center gap-2 px-3 py-2 bg-emerald-500/10 text-emerald-400 rounded-xl border border-emerald-500/20">
            <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></div>
            <span className="text-xs font-bold">نظام AI نشط</span>
          </div>
          <button className="bg-blue-600 hover:bg-blue-500 text-white text-sm px-4 py-2 rounded-xl font-bold shadow-lg shadow-blue-900/20 flex items-center gap-2 transition-colors">
            <Target className="w-4 h-4" />
            إنشاء حملة
          </button>
        </div>
      </div>

      {/* Top Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard title="الحملات النشطة" value="12" change="+2" icon={Target} color="text-blue-600" bg="bg-blue-50" />
        <StatCard title="بانتظار الموافقة" value="5" change="عاجل" icon={Clock} color="text-amber-600" bg="bg-amber-50" />
        <StatCard title="منشورات مجدولة" value="24" change="+8" icon={CheckCircle2} color="text-green-600" bg="bg-green-50" />
        <StatCard title="معدل التحويل" value="3.8%" change="+1.2%" icon={TrendingUp} color="text-indigo-600" bg="bg-indigo-50" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main Chart Area Placeholder */}
        <div className="lg:col-span-2 bg-[#11141b] rounded-3xl border border-slate-800 p-6 flex flex-col">
          <div className="flex justify-between items-center mb-6">
            <h3 className="text-white font-bold">أداء الحملات</h3>
            <select className="bg-[#161a23] border border-slate-800 text-slate-300 text-xs font-medium rounded-lg focus:ring-1 focus:ring-blue-500 focus:border-blue-500 p-2 outline-none">
              <option>آخر 7 أيام</option>
              <option>آخر 30 يوم</option>
              <option>هذا الشهر</option>
            </select>
          </div>
          <div className="flex-1 min-h-[16rem] flex items-center justify-center border border-dashed border-slate-800 rounded-2xl bg-[#0d0f14]/50">
            <div className="text-center">
              <BarChartIcon className="w-10 h-10 text-slate-700 mx-auto mb-2" />
              <p className="text-slate-500 text-xs">مساحة الرسم البياني (سيتم دمج Recharts لاحقاً)</p>
            </div>
          </div>
        </div>

        {/* AI Recommendations / Alerts */}
        <div className="bg-[#11141b] rounded-3xl border border-slate-800 p-6 flex flex-col relative overflow-hidden">
          <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-blue-600 to-indigo-600"></div>
          
          <div className="flex items-center justify-between mb-4 mt-2">
            <div>
              <span className="text-[10px] text-blue-400 font-bold tracking-[0.1em] uppercase">مركز التنبيهات</span>
              <h2 className="text-lg font-bold text-white mt-1">توصيات الذكاء الاصطناعي</h2>
            </div>
          </div>
          
          <div className="space-y-4 flex-1 overflow-y-auto pr-2 custom-scrollbar">
            <RecommendationItem 
              type="approval"
              title="محتوى جديد بانتظار الموافقة"
              desc="قام AI Agent بإنشاء 3 منشورات لحملة 'إطلاق الصيف'."
              time="منذ 10 دقائق"
            />
            <RecommendationItem 
              type="insight"
              title="فرصة تحسين"
              desc="منشورات الانستغرام تحقق تفاعلاً أعلى بنسبة 15% في المساء. هل نعدل جدول النشر؟"
              time="منذ ساعة"
            />
            <RecommendationItem 
              type="warning"
              title="ميزانية الحملة"
              desc="حملة 'العودة للمدارس' تستهلك الميزانية أسرع من المتوقع. راجع الأداء."
              time="منذ 3 ساعات"
            />
          </div>

          <button className="w-full mt-4 py-2.5 text-sm text-slate-400 font-bold border border-slate-800 rounded-xl hover:bg-slate-800 transition-colors">
            عرض كل التنبيهات
          </button>
        </div>
      </div>
      
      {/* Recent Platforms Connected */}
      <div className="bg-[#11141b] rounded-3xl border border-slate-800 p-6">
        <h2 className="text-white font-bold mb-4">حالة المنصات</h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <PlatformStatus name="Facebook" status="متصل" active={true} letter="F" color="bg-blue-500/20 text-blue-400" />
          <PlatformStatus name="Instagram" status="متصل" active={true} letter="I" color="bg-pink-500/20 text-pink-400" />
          <PlatformStatus name="X (Twitter)" status="غير متصل" active={false} letter="X" color="bg-slate-800 text-slate-400" />
          <PlatformStatus name="TikTok" status="تحتاج تحديث" active={false} letter="T" color="bg-slate-800 text-slate-400" />
        </div>
      </div>
    </div>
  );
}

function StatCard({ title, value, change, icon: Icon, color, bg }: any) {
  let darkColor = color;
  let darkBg = bg;
  
  if (color.includes('blue')) { darkColor = 'text-blue-400'; darkBg = 'bg-blue-500/20'; }
  else if (color.includes('amber')) { darkColor = 'text-orange-400'; darkBg = 'bg-orange-500/20'; }
  else if (color.includes('green')) { darkColor = 'text-emerald-400'; darkBg = 'bg-emerald-500/20'; }
  else if (color.includes('indigo')) { darkColor = 'text-indigo-400'; darkBg = 'bg-indigo-500/20'; }

  return (
    <div className="bg-[#11141b] rounded-3xl p-5 border border-slate-800 flex items-start justify-between relative overflow-hidden group">
      <div className="z-10">
        <p className="text-xs font-bold text-slate-500 mb-1">{title}</p>
        <h3 className="text-2xl font-bold text-white leading-none">{value}</h3>
        <p className={`text-[10px] font-bold mt-2 flex items-center gap-1 ${change.includes('+') ? 'text-emerald-400' : change === 'عاجل' ? 'text-orange-400' : 'text-slate-500'}`}>
          {change} {change.includes('+') && '↑'}
        </p>
      </div>
      <div className={`p-2.5 rounded-xl ${darkBg} border border-slate-700/50 z-10`}>
        <Icon className={`w-5 h-5 ${darkColor}`} />
      </div>
      {/* Background glow decoration */}
      <div className={`absolute -bottom-6 -left-6 w-24 h-24 rounded-full ${darkBg} opacity-20 blur-2xl group-hover:opacity-40 transition-opacity`}></div>
    </div>
  );
}

function RecommendationItem({ title, desc, time, type }: any) {
  let badgeColor = 'bg-slate-800 text-slate-300';
  if (type === 'approval') badgeColor = 'bg-blue-600/20 text-blue-400 border border-blue-600/30';
  if (type === 'insight') badgeColor = 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30';
  if (type === 'warning') badgeColor = 'bg-orange-500/20 text-orange-400 border border-orange-500/30';

  return (
    <div className="p-4 bg-[#161a23] rounded-2xl border border-slate-800 hover:border-slate-700 transition-colors">
      <div className="flex justify-between items-start mb-2">
        <span className={`text-[10px] px-2 py-0.5 rounded font-bold ${badgeColor}`}>{title}</span>
        <span className="text-[10px] text-slate-500">{time}</span>
      </div>
      <p className="text-xs text-slate-400 font-medium leading-relaxed mb-3">{desc}</p>
      {type === 'approval' && (
        <div className="flex gap-2">
          <button className="flex-1 py-2 bg-blue-600 text-white rounded-lg text-[10px] font-bold shadow-lg shadow-blue-900/20 hover:bg-blue-500 transition-colors">مراجعة واعتماد</button>
          <button className="flex-1 py-2 bg-slate-800 text-slate-300 rounded-lg text-[10px] font-bold border border-slate-700 hover:bg-slate-700 transition-colors">تجاهل</button>
        </div>
      )}
    </div>
  );
}

function PlatformStatus({ name, status, active, letter, color }: any) {
  return (
    <div className="flex items-center gap-3 p-3 border border-slate-800 rounded-2xl bg-[#161a23]">
      <div className={`w-8 h-8 rounded-lg flex items-center justify-center text-xs font-bold ${color}`}>
        {letter || name[0]}
      </div>
      <div>
        <p className="text-xs font-bold text-slate-300">{name}</p>
        <div className="flex items-center gap-1.5 mt-0.5">
          <div className={`w-1.5 h-1.5 rounded-full ${active ? 'bg-emerald-500' : status.includes('تحديث') ? 'bg-orange-500' : 'bg-slate-500'}`} />
          <p className="text-[10px] text-slate-500">{status}</p>
        </div>
      </div>
    </div>
  );
}

function BarChartIcon(props: any) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <line x1="12" x2="12" y1="20" y2="10" />
      <line x1="18" x2="18" y1="20" y2="4" />
      <line x1="6" x2="6" y1="20" y2="16" />
    </svg>
  );
}
