import React, { useState, useRef, useEffect } from 'react';
import { 
  Send, Copy, Check, ClipboardPaste, Code2, AlertCircle, 
  MessageSquare, Settings, Shield, FileSearch, FlaskConical,
  Plus, MoreVertical, Trash2, Edit2, PanelRightClose, PanelRight,
  Paperclip, StopCircle, Bot, User, RefreshCw, ChevronDown, Sparkles, X, Menu, UploadCloud, FileJson, FileCode2, FileArchive, FileText
} from 'lucide-react';
import Markdown from 'react-markdown';
import { Prism as SyntaxHighlighter } from 'react-syntax-highlighter';
import { vscDarkPlus } from 'react-syntax-highlighter/dist/esm/styles/prism';
import JSZip from 'jszip';

type Mode = 'Chat' | 'Developer' | 'Security' | 'Analyzer' | 'Lab';

interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  isError?: boolean;
}

interface ChatSession {
  id: string;
  title: string;
  messages: Message[];
  mode: Mode;
  updatedAt: number;
}

interface Attachment {
  id: string;
  name: string;
  content: string;
  isZip: boolean;
  size: number;
  filesCount?: number;
}

const MODES: { id: Mode; label: string; icon: React.FC<any>; desc: string; color: string }[] = [
  { id: 'Chat', label: 'مساعد عام', icon: MessageSquare, desc: 'نقاش عام وإجابات سريعة', color: 'text-blue-400' },
  { id: 'Developer', label: 'مطور (Developer)', icon: Code2, desc: 'كتابة ومراجعة الأكواد', color: 'text-emerald-400' },
  { id: 'Security', label: 'أمان (Security)', icon: Shield, desc: 'فحص الثغرات والحماية', color: 'text-red-400' },
  { id: 'Analyzer', label: 'محلل (Analyzer)', icon: FileSearch, desc: 'تحليل البيانات والمشاريع', color: 'text-purple-400' },
  { id: 'Lab', label: 'مختبر (Lab)', icon: FlaskConical, desc: 'تجارب وأفكار إبداعية', color: 'text-amber-400' },
];

export const AIAssistantPage: React.FC = () => {
  // State
  const [sessions, setSessions] = useState<ChatSession[]>([]);
  const [activeSessionId, setActiveSessionId] = useState<string | null>(null);
  const [input, setInput] = useState('');
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const [isMobile, setIsMobile] = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);
  const [statusMessage, setStatusMessage] = useState<string | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [showModeSelector, setShowModeSelector] = useState(false);
  const [attachments, setAttachments] = useState<Attachment[]>([]);
  const [isProcessingFile, setIsProcessingFile] = useState(false);

  // Refs
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const abortControllerRef = useRef<AbortController | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Load Sessions
  useEffect(() => {
    const saved = localStorage.getItem('ai_sessions');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        setSessions(parsed);
        if (parsed.length > 0) setActiveSessionId(parsed[0].id);
      } catch (e) {
        console.error('Failed to parse sessions', e);
      }
    } else {
      createNewSession();
    }

    const checkMobile = () => {
      const mobile = window.innerWidth < 768;
      setIsMobile(mobile);
      if (mobile) setIsSidebarOpen(false);
    };
    checkMobile();
    window.addEventListener('resize', checkMobile);
    return () => window.removeEventListener('resize', checkMobile);
  }, []);

  // Save Sessions
  useEffect(() => {
    if (sessions.length > 0) {
      localStorage.setItem('ai_sessions', JSON.stringify(sessions));
    }
  }, [sessions]);

  // Scroll to bottom
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [sessions, activeSessionId]);

  // Auto-resize textarea
  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = `${Math.min(textareaRef.current.scrollHeight, 200)}px`;
    }
  }, [input]);

  const activeSession = sessions.find((s) => s.id === activeSessionId);
  const activeMode = MODES.find((m) => m.id === (activeSession?.mode || 'Chat'));

  const showFeedback = (msg: string) => {
    setStatusMessage(msg);
    setTimeout(() => setStatusMessage(null), 3000);
  };

  const createNewSession = (mode: Mode = 'Chat') => {
    const newSession: ChatSession = {
      id: Date.now().toString(),
      title: 'محادثة جديدة',
      messages: [],
      mode,
      updatedAt: Date.now(),
    };
    setSessions((prev) => [newSession, ...prev]);
    setActiveSessionId(newSession.id);
    if (isMobile) setIsSidebarOpen(false);
  };

  const deleteSession = (e: React.MouseEvent, id: string) => {
    e.stopPropagation();
    setSessions((prev) => prev.filter((s) => s.id !== id));
    if (activeSessionId === id) {
      const remaining = sessions.filter((s) => s.id !== id);
      setActiveSessionId(remaining.length > 0 ? remaining[0].id : null);
      if (remaining.length === 0) createNewSession();
    }
  };

  const changeSessionMode = (mode: Mode) => {
    if (!activeSession) return;
    setSessions((prev) =>
      prev.map((s) => (s.id === activeSessionId ? { ...s, mode } : s))
    );
    setShowModeSelector(false);
  };

  const handleFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files || e.target.files.length === 0) return;
    
    setIsProcessingFile(true);
    const newAttachments: Attachment[] = [];
    
    for (let i = 0; i < e.target.files.length; i++) {
      const file = e.target.files[i];
      const isZip = file.name.toLowerCase().endsWith('.zip');
      
      try {
        if (isZip) {
          const zip = new JSZip();
          const zipContent = await zip.loadAsync(file);
          const validExtensions = ['.ts', '.tsx', '.js', '.jsx', '.json', '.md', '.txt', '.html', '.css'];
          let extractedContent = `--- Project Archive: ${file.name} ---\n\n`;
          let filesCount = 0;

          for (const relativePath in zipContent.files) {
            const zipEntry = zipContent.files[relativePath];
            
            // Skip directories and ignored folders (node_modules, .git, etc.)
            if (
              zipEntry.dir || 
              relativePath.includes('node_modules/') || 
              relativePath.includes('.git/') ||
              relativePath.includes('dist/') ||
              relativePath.includes('build/') ||
              relativePath.includes('.next/')
            ) {
              continue;
            }

            // Check if valid code/text file
            const ext = relativePath.substring(relativePath.lastIndexOf('.')).toLowerCase();
            if (validExtensions.includes(ext) || relativePath.includes('.env.example')) {
              const fileData = await zipEntry.async('string');
              extractedContent += `\n\n--- File: ${relativePath} ---\n\`\`\`\n${fileData}\n\`\`\`\n`;
              filesCount++;
            }
          }
          
          if (filesCount > 0) {
            newAttachments.push({
              id: Date.now().toString() + i,
              name: file.name,
              content: extractedContent,
              isZip: true,
              size: file.size,
              filesCount
            });
            showFeedback(`تم فحص وتحليل ${filesCount} ملفات من المشروع`);
          } else {
            showFeedback(`لم يتم العثور على ملفات برمجية صالحة في ${file.name}`);
          }

        } else {
          // Read normal text file
          const text = await file.text();
          newAttachments.push({
            id: Date.now().toString() + i,
            name: file.name,
            content: `\n\n--- File: ${file.name} ---\n\`\`\`\n${text}\n\`\`\`\n`,
            isZip: false,
            size: file.size
          });
        }
      } catch (err) {
        console.error('Error processing file:', err);
        showFeedback(`حدث خطأ أثناء معالجة الملف ${file.name}`);
      }
    }

    setAttachments(prev => [...prev, ...newAttachments]);
    setIsProcessingFile(false);
    
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const removeAttachment = (id: string) => {
    setAttachments(prev => prev.filter(a => a.id !== id));
  };

  const handleSend = async () => {
    if ((!input.trim() && attachments.length === 0) || !activeSessionId || isGenerating) return;

    let finalPrompt = input.trim();
    
    // Append attachments to the actual prompt sent to the server
    if (attachments.length > 0) {
      const attachmentsText = attachments.map(a => a.content).join('\n');
      finalPrompt = `[مرفقات المشروع / الملفات]:\n${attachmentsText}\n\n[طلب المستخدم]:\n${finalPrompt}`;
    }

    // Record user message (Display version)
    const userDisplayMsg = input.trim() + (attachments.length > 0 ? `\n\n*(تم إرفاق ${attachments.length} ملفات / مشاريع)*` : '');
    
    setInput('');
    setAttachments([]);
    if (textareaRef.current) textareaRef.current.style.height = 'auto';

    const userMsg: Message = { id: Date.now().toString(), role: 'user', content: userDisplayMsg };
    
    // Update session title if it's the first message
    setSessions((prev) =>
      prev.map((s) => {
        if (s.id === activeSessionId) {
          return {
            ...s,
            title: s.messages.length === 0 ? (input.trim().slice(0, 30) || 'تحليل ملفات') + '...' : s.title,
            messages: [...s.messages, userMsg],
            updatedAt: Date.now(),
          };
        }
        return s;
      })
    );

    setIsGenerating(true);
    abortControllerRef.current = new AbortController();

    try {
      // Fake delay for realistic feeling
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      const response = await fetch('/api/advisor', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt: finalPrompt, advisorId: null }),
        signal: abortControllerRef.current.signal
      });

      let assistantText = "عذراً، حدث خطأ في معالجة طلبك.";
      if (response.ok) {
        const data = await response.json();
        assistantText = data.text;
      }

      const assistantMsg: Message = { id: (Date.now()+1).toString(), role: 'assistant', content: assistantText };
      
      setSessions((prev) =>
        prev.map((s) => (s.id === activeSessionId ? { ...s, messages: [...s.messages, assistantMsg], updatedAt: Date.now() } : s))
      );
    } catch (err: any) {
      if (err.name === 'AbortError') {
         showFeedback('تم إيقاف التوليد');
      } else {
        const errorMsg: Message = { id: (Date.now()+1).toString(), role: 'assistant', content: 'حدث خطأ في الاتصال بالخادم.', isError: true };
        setSessions((prev) =>
          prev.map((s) => (s.id === activeSessionId ? { ...s, messages: [...s.messages, errorMsg], updatedAt: Date.now() } : s))
        );
      }
    } finally {
      setIsGenerating(false);
      abortControllerRef.current = null;
    }
  };

  const handleStop = () => {
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const copyToClipboard = async (text: string, id: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopiedId(id);
      setTimeout(() => setCopiedId(null), 2000);
    } catch {
      showFeedback('فشل النسخ');
    }
  };

  const formatFileSize = (bytes: number) => {
    if (bytes < 1024) return bytes + ' B';
    else if (bytes < 1048576) return (bytes / 1024).toFixed(1) + ' KB';
    else return (bytes / 1048576).toFixed(1) + ' MB';
  };

  return (
    <div className="flex h-[calc(100vh-4rem)] md:h-[calc(100vh-5rem)] bg-[#0a0a0f] text-slate-200 font-sans overflow-hidden relative">
      
      {/* Toast Alert */}
      {statusMessage && (
        <div className="fixed top-4 left-1/2 -translate-x-1/2 bg-slate-800 border border-slate-700 text-white text-sm px-6 py-3 rounded-full flex items-center gap-2 shadow-2xl z-50 animate-fade-in">
          <AlertCircle className="w-4 h-4 text-blue-400" />
          {statusMessage}
        </div>
      )}

      {/* Sidebar Overlay (Mobile) */}
      {isMobile && isSidebarOpen && (
        <div 
          className="fixed inset-0 bg-black/60 z-40 backdrop-blur-sm transition-opacity"
          onClick={() => setIsSidebarOpen(false)}
        />
      )}

      {/* Sidebar */}
      <div 
        className={`${isSidebarOpen ? 'w-72 translate-x-0' : 'w-0 translate-x-full md:translate-x-0 md:w-0'} 
          fixed md:relative right-0 top-0 bottom-0 z-50 bg-[#11141b] border-l border-slate-800/60 transition-all duration-300 flex flex-col shrink-0
          ${!isSidebarOpen && 'md:hidden'} overflow-hidden
        `}
      >
        <div className="p-4 w-72">
          <button 
            onClick={() => createNewSession()}
            className="w-full flex items-center gap-2 bg-slate-800 hover:bg-slate-700 text-white px-4 py-3 rounded-xl transition-colors font-medium border border-slate-700/50"
          >
            <Plus className="w-5 h-5" />
            محادثة جديدة
          </button>
        </div>
        
        <div className="flex-1 overflow-y-auto px-3 pb-4 space-y-1 custom-scrollbar w-72">
          <div className="text-xs font-semibold text-slate-500 mb-3 px-3 mt-2">السجل</div>
          {sessions.map((session) => (
            <button
              key={session.id}
              onClick={() => { setActiveSessionId(session.id); if (isMobile) setIsSidebarOpen(false); }}
              className={`w-full flex items-center justify-between p-3 rounded-xl transition-all group text-right ${
                activeSessionId === session.id 
                  ? 'bg-blue-600/10 text-blue-400 border border-blue-500/20' 
                  : 'hover:bg-slate-800/50 text-slate-300 border border-transparent'
              }`}
            >
              <div className="flex items-center gap-3 overflow-hidden">
                <MessageSquare className={`w-4 h-4 shrink-0 ${activeSessionId === session.id ? 'text-blue-400' : 'text-slate-500'}`} />
                <span className="truncate text-sm">{session.title}</span>
              </div>
              <div 
                className="opacity-0 group-hover:opacity-100 p-1 hover:bg-slate-700 rounded transition-all shrink-0"
                onClick={(e) => deleteSession(e, session.id)}
              >
                <Trash2 className="w-4 h-4 text-red-400/70 hover:text-red-400" />
              </div>
            </button>
          ))}
          {sessions.length === 0 && (
            <div className="text-center text-slate-500 text-sm py-10">لا توجد محادثات سابقة</div>
          )}
        </div>
      </div>

      {/* Main Area */}
      <div className="flex-1 flex flex-col relative w-full h-full overflow-hidden">
        
        {/* Header */}
        <header className="h-16 shrink-0 border-b border-slate-800/60 bg-[#0a0a0f]/80 backdrop-blur-md flex items-center justify-between px-4 z-30">
          <div className="flex items-center gap-3">
            <button 
              onClick={() => setIsSidebarOpen(!isSidebarOpen)}
              className="p-2 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
            >
              {isSidebarOpen ? <PanelRightClose className="w-5 h-5" /> : <PanelRight className="w-5 h-5" />}
            </button>
            
            {/* Mode Selector */}
            <div className="relative">
              <button 
                onClick={() => setShowModeSelector(!showModeSelector)}
                className="flex items-center gap-2 hover:bg-slate-800 px-3 py-1.5 rounded-lg transition-colors"
              >
                {activeMode && <activeMode.icon className={`w-5 h-5 ${activeMode.color}`} />}
                <span className="font-semibold text-slate-100">{activeMode?.label}</span>
                <ChevronDown className="w-4 h-4 text-slate-400" />
              </button>

              {showModeSelector && (
                <div className="absolute top-full right-0 mt-2 w-64 bg-[#161a23] border border-slate-700 rounded-xl shadow-2xl py-2 z-50">
                  {MODES.map((mode) => (
                    <button
                      key={mode.id}
                      onClick={() => changeSessionMode(mode.id)}
                      className={`w-full text-right px-4 py-3 flex items-start gap-3 hover:bg-slate-800 transition-colors ${activeSession?.mode === mode.id ? 'bg-slate-800/50' : ''}`}
                    >
                      <mode.icon className={`w-5 h-5 mt-0.5 shrink-0 ${mode.color}`} />
                      <div>
                        <div className="font-semibold text-slate-200 text-sm">{mode.label}</div>
                        <div className="text-xs text-slate-500 mt-0.5">{mode.desc}</div>
                      </div>
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>
          
          <div className="flex items-center gap-2">
             <button className="p-2 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors" title="إعدادات المساعد">
               <Settings className="w-5 h-5" />
             </button>
          </div>
        </header>

        {/* Chat Feed */}
        <div className="flex-1 overflow-y-auto px-4 md:px-8 pb-40 pt-8 custom-scrollbar scroll-smooth">
          <div className="max-w-3xl mx-auto flex flex-col space-y-8">
            
            {!activeSession?.messages.length && (
              <div className="flex flex-col items-center justify-center py-20 text-center animate-fade-in">
                <div className="w-20 h-20 bg-gradient-to-br from-blue-500/20 to-purple-500/20 rounded-3xl flex items-center justify-center mb-6 border border-white/5">
                  <Sparkles className="w-10 h-10 text-blue-400" />
                </div>
                <h2 className="text-2xl font-bold text-slate-100 mb-3">كيف يمكنني مساعدتك اليوم؟</h2>
                <p className="text-slate-400 max-w-md text-sm leading-relaxed mb-8">
                  أنا المساعد الذكي، جاهز لكتابة الأكواد، تحليل الملفات، والإجابة على استفساراتك التقنية بأعلى احترافية. يمكنك رفع ملفات أو مشاريع كاملة (ZIP) وسأقوم بتحليلها!
                </p>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3 w-full max-w-lg">
                   <button onClick={() => { setInput("قم بتحليل أداء موقعي واقترح تحسينات"); if(textareaRef.current) textareaRef.current.focus(); }} className="bg-slate-800/50 hover:bg-slate-800 border border-slate-700/50 p-4 rounded-2xl text-right transition-colors text-sm text-slate-300">
                     تحليل الأداء والتحسينات &rarr;
                   </button>
                   <button onClick={() => { setInput("اكتب لي كود React لمكون تسجيل دخول"); if(textareaRef.current) textareaRef.current.focus(); }} className="bg-slate-800/50 hover:bg-slate-800 border border-slate-700/50 p-4 rounded-2xl text-right transition-colors text-sm text-slate-300">
                     برمجة مكون تسجيل دخول &rarr;
                   </button>
                </div>
              </div>
            )}

            {activeSession?.messages.map((msg) => (
              <div key={msg.id} className={`flex w-full group ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                
                {msg.role === 'user' ? (
                  // User Message
                  <div className="bg-slate-800 text-slate-100 px-5 py-3.5 rounded-3xl rounded-tr-sm max-w-[85%] md:max-w-[75%] shadow-sm">
                    <div className="whitespace-pre-wrap text-[15px] leading-relaxed font-sans">{msg.content}</div>
                  </div>
                ) : (
                  // Assistant Message
                  <div className="flex gap-4 w-full">
                    <div className={`w-8 h-8 rounded-full shrink-0 flex items-center justify-center text-white mt-1 ${msg.isError ? 'bg-red-500/20 text-red-400' : 'bg-gradient-to-br from-blue-600 to-indigo-600'}`}>
                      {msg.isError ? <AlertCircle className="w-4 h-4" /> : <Sparkles className="w-4 h-4" />}
                    </div>
                    
                    <div className="flex-1 w-full min-w-0">
                      <div className="prose prose-invert prose-slate max-w-none text-[15px] leading-relaxed">
                        <Markdown
                          components={{
                            code({node, inline, className, children, ...props}: any) {
                              const match = /language-(\w+)/.exec(className || '')
                              const codeString = String(children).replace(/\n$/, '');
                              
                              if (!inline && match) {
                                return (
                                  <div className="relative my-4 rounded-xl overflow-hidden bg-[#1e1e1e] border border-slate-700/50 dir-ltr text-left">
                                    <div className="flex items-center justify-between px-4 py-2 bg-slate-800/80 border-b border-slate-700/50">
                                      <span className="text-xs font-mono text-slate-400 uppercase">{match[1]}</span>
                                      <button
                                        onClick={() => copyToClipboard(codeString, `${msg.id}-${codeString.substring(0,10)}`)}
                                        className="text-slate-400 hover:text-white flex items-center gap-1.5 transition-colors bg-slate-700/50 hover:bg-slate-700 px-2.5 py-1 rounded-md"
                                      >
                                        {copiedId === `${msg.id}-${codeString.substring(0,10)}` ? (
                                          <><Check className="w-3.5 h-3.5 text-emerald-400" /><span className="text-[11px] text-emerald-400">Copied!</span></>
                                        ) : (
                                          <><Copy className="w-3.5 h-3.5" /><span className="text-[11px]">Copy code</span></>
                                        )}
                                      </button>
                                    </div>
                                    <div className="p-1 overflow-x-auto text-sm font-mono custom-scrollbar">
                                      <SyntaxHighlighter
                                        {...props}
                                        style={vscDarkPlus}
                                        language={match[1]}
                                        PreTag="div"
                                        customStyle={{ margin: 0, background: 'transparent', padding: '1rem' }}
                                      >
                                        {codeString}
                                      </SyntaxHighlighter>
                                    </div>
                                  </div>
                                )
                              }
                              return (
                                <code {...props} className={`${className} bg-slate-800 text-blue-300 px-1.5 py-0.5 rounded-md font-mono text-sm border border-slate-700`} dir="ltr">
                                  {children}
                                </code>
                              )
                            }
                          }}
                        >
                          {msg.content}
                        </Markdown>
                      </div>
                      
                      {/* Message Actions */}
                      <div className="flex items-center gap-2 mt-3 opacity-0 group-hover:opacity-100 transition-opacity">
                        <button 
                          onClick={() => copyToClipboard(msg.content, msg.id)}
                          className="text-slate-500 hover:text-slate-300 p-1.5 hover:bg-slate-800 rounded-lg transition-colors flex items-center gap-1.5"
                          title="نسخ الرد"
                        >
                          {copiedId === msg.id ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                        </button>
                        {!msg.isError && (
                          <button className="text-slate-500 hover:text-slate-300 p-1.5 hover:bg-slate-800 rounded-lg transition-colors" title="إعادة التوليد">
                            <RefreshCw className="w-4 h-4" />
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                )}
              </div>
            ))}

            {isGenerating && (
              <div className="flex gap-4 w-full animate-pulse">
                <div className="w-8 h-8 rounded-full shrink-0 flex items-center justify-center bg-gradient-to-br from-blue-600 to-indigo-600 text-white mt-1">
                  <Sparkles className="w-4 h-4" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="inline-flex flex-col gap-2">
                    <div className="bg-slate-800/50 border border-slate-700/50 rounded-xl px-4 py-2.5 flex items-center gap-3 w-fit">
                      <div className="w-4 h-4 border-2 border-blue-500 border-t-transparent rounded-full animate-spin"></div>
                      <span className="text-sm font-medium text-blue-400">
                        {activeSession?.mode === 'Security' ? 'جاري فحص الثغرات والأمان...' : 
                         activeSession?.mode === 'Developer' ? 'جاري كتابة الكود والمراجعة...' : 
                         activeSession?.mode === 'Analyzer' ? 'جاري تحليل المعطيات...' : 
                         'المساعد يفكر...'}
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            )}
            
            <div ref={messagesEndRef} className="h-4" />
          </div>
        </div>

        {/* Input Area */}
        <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-[#0a0a0f] via-[#0a0a0f] to-[#0a0a0f]/80 pt-16 pb-6 px-4 md:px-8">
          <div className="max-w-3xl mx-auto relative">
            
            <div className="relative bg-[#161a23] border border-slate-700/80 rounded-3xl shadow-2xl focus-within:ring-1 focus-within:ring-slate-500 transition-all flex flex-col overflow-hidden">
              
              {/* Attachments Area */}
              {attachments.length > 0 && (
                <div className="flex flex-wrap gap-2 px-3 pt-3 pb-1 max-h-32 overflow-y-auto custom-scrollbar border-b border-slate-800/50 bg-slate-900/30">
                  {attachments.map(att => (
                    <div key={att.id} className="flex items-center gap-2 bg-slate-800 border border-slate-700 px-2.5 py-1.5 rounded-lg text-sm max-w-[200px]">
                      <div className="w-6 h-6 rounded flex items-center justify-center shrink-0 bg-slate-700">
                        {att.isZip ? <FileArchive className="w-3.5 h-3.5 text-blue-400" /> : <FileText className="w-3.5 h-3.5 text-emerald-400" />}
                      </div>
                      <div className="flex flex-col min-w-0 flex-1">
                        <span className="truncate text-slate-200 text-xs font-medium" dir="ltr">{att.name}</span>
                        <span className="text-[10px] text-slate-500">
                          {formatFileSize(att.size)} {att.filesCount ? `(${att.filesCount} ملفات)` : ''}
                        </span>
                      </div>
                      <button 
                        onClick={() => removeAttachment(att.id)}
                        className="p-1 hover:bg-slate-700 rounded-md text-slate-400 hover:text-white transition-colors shrink-0"
                      >
                        <X className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ))}
                </div>
              )}

              <div className="flex items-end px-2 py-2">
                <input 
                  type="file" 
                  ref={fileInputRef}
                  onChange={handleFileSelect}
                  className="hidden" 
                  multiple 
                  accept=".zip,.txt,.md,.json,.ts,.js,.tsx,.jsx,.html,.css"
                />
                
                <button 
                  onClick={() => fileInputRef.current?.click()}
                  disabled={isProcessingFile}
                  className="p-2.5 text-slate-400 hover:text-white rounded-xl hover:bg-slate-800 transition-colors shrink-0 flex items-center justify-center mb-0.5 group disabled:opacity-50"
                  title="إرفاق ملفات أو مجلد مشروع ZIP"
                >
                  {isProcessingFile ? (
                    <div className="w-5 h-5 border-2 border-slate-400 border-t-transparent rounded-full animate-spin"></div>
                  ) : (
                    <Paperclip className="w-5 h-5 group-hover:rotate-12 transition-transform" />
                  )}
                </button>
                
                <textarea
                  ref={textareaRef}
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  onKeyDown={handleKeyDown}
                  placeholder="أرسل رسالة للمساعد... (Shift + Enter لسطر جديد)"
                  className="flex-1 max-h-48 bg-transparent border-none focus:outline-none text-slate-100 px-3 py-3.5 text-[15px] resize-none overflow-y-auto custom-scrollbar"
                  rows={1}
                  style={{ minHeight: '52px' }}
                />
                
                <div className="flex shrink-0 mb-1 ml-2">
                  {isGenerating ? (
                    <button
                      onClick={handleStop}
                      className="w-10 h-10 bg-slate-800 text-slate-300 hover:bg-slate-700 hover:text-white rounded-full flex items-center justify-center transition-colors shadow-sm border border-slate-700"
                      title="إيقاف التوليد"
                    >
                      <StopCircle className="w-5 h-5" />
                    </button>
                  ) : (
                    <button
                      onClick={handleSend}
                      disabled={(!input.trim() && attachments.length === 0) || isProcessingFile}
                      className="w-10 h-10 bg-white text-slate-900 disabled:bg-slate-800 disabled:text-slate-500 disabled:border-transparent border border-white rounded-full flex items-center justify-center transition-colors shadow-sm hover:bg-slate-200"
                      title="إرسال"
                    >
                      <Send className="w-4 h-4 rtl:-scale-x-100 ml-0.5" />
                    </button>
                  )}
                </div>
              </div>
            </div>
            
            <div className="text-center mt-3">
              <span className="text-[11px] text-slate-500 font-medium">
                المساعد الذكي قيد التطوير وقد يقدم معلومات غير دقيقة. يرجى مراجعة الأكواد قبل استخدامها في الإنتاج.
              </span>
            </div>
          </div>
        </div>

      </div>
    </div>
  );
};

export default AIAssistantPage;
