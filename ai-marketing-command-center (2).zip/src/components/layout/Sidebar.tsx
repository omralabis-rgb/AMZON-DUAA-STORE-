import { Link, useLocation } from "react-router-dom";
import { cn } from "@/lib/utils";
import { 
  Home, 
  Bot, 
  Package, 
  Target, 
  PenTool, 
  Calendar, 
  CheckCircle2, 
  Share2, 
  BarChart3, 
  Fingerprint, 
  Settings, 
  ShieldAlert, 
  ScrollText,
  BrainCircuit,
  Users,
  Code2
} from "lucide-react";

const navItems = [
  { name: "الرئيسية", path: "/", icon: Home },
  { name: "المستشار", path: "/advisor", icon: BrainCircuit },
  { name: "إدارة المستشارين", path: "/advisors-manager", icon: Users },
  { name: "محرك الوكلاء", path: "/agent", icon: Bot },
  { name: "المساعد البرمجي", path: "/ai-assistant", icon: Code2 },
  { name: "المنتجات", path: "/products", icon: Package },
  { name: "NOVA Studio", path: "/nova.html", icon: ScrollText, external: true },
  { name: "الحملات", path: "/campaigns", icon: Target },
  { name: "Content Studio", path: "/content-studio", icon: PenTool },
  { name: "التقويم", path: "/calendar", icon: Calendar },
  { name: "Approval Center", path: "/approval-center", icon: CheckCircle2 },
  { name: "الحسابات", path: "/accounts", icon: Share2 },
  { name: "Analytics", path: "/analytics", icon: BarChart3 },
  { name: "Brand DNA", path: "/brand", icon: Fingerprint },
  { name: "الإعدادات", path: "/settings", icon: Settings },
  { name: "Security", path: "/security", icon: ShieldAlert },
  { name: "Audit Logs", path: "/audit-logs", icon: ScrollText },
];

interface SidebarProps {
  isOpen?: boolean;
  setIsOpen?: (isOpen: boolean) => void;
}

export default function Sidebar({ isOpen, setIsOpen }: SidebarProps) {
  const location = useLocation();

  return (
    <aside 
      className={cn(
        "w-64 bg-[#11141b] border-l border-slate-800 flex flex-col h-full shrink-0 z-50 fixed md:static top-0 right-0 transition-transform duration-300 ease-in-out",
        isOpen ? "translate-x-0" : "translate-x-full md:translate-x-0"
      )}
    >
      <div className="h-16 flex items-center px-6 border-b border-slate-800">
        <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center font-bold text-white shadow-lg shadow-blue-900/20 ml-3">AI</div>
        <span className="font-bold text-lg text-white tracking-tight truncate">مركز القيادة</span>
      </div>

      <nav className="flex-1 overflow-y-auto py-4 space-y-1 px-3 custom-scrollbar">
        {navItems.map((item) => {
          const isActive = location.pathname === item.path;
          const linkClasses = cn(
            "flex items-center gap-3 px-4 py-3 rounded-xl transition-colors text-sm font-medium border border-transparent",
            isActive 
              ? "bg-blue-600/10 text-blue-400 border-blue-600/20" 
              : "text-slate-400 hover:bg-slate-800"
          );

          if (item.external) {
            return (
              <a
                key={item.path}
                href={item.path}
                target="_blank"
                rel="noopener noreferrer"
                onClick={() => setIsOpen?.(false)}
                className={linkClasses}
              >
                <item.icon className={cn("w-5 h-5", isActive ? "text-blue-400" : "text-slate-500")} />
                {item.name}
              </a>
            );
          }

          return (
            <Link
              key={item.path}
              to={item.path}
              onClick={() => setIsOpen?.(false)}
              className={linkClasses}
            >
              <item.icon className={cn("w-5 h-5", isActive ? "text-blue-400" : "text-slate-500")} />
              {item.name}
            </Link>
          );
        })}
      </nav>

      <div className="p-4 border-t border-slate-800 bg-[#0d0f14]">
        <div className="bg-gradient-to-br from-indigo-900/40 to-slate-900 border border-indigo-500/30 rounded-xl p-4 text-white shadow-md">
          <h4 className="text-sm font-bold mb-1 text-white">Demo Mode</h4>
          <p className="text-xs text-slate-400 mb-3 opacity-90">النظام يعمل في وضع التجربة حالياً.</p>
          <button className="w-full bg-blue-600 text-white text-xs font-bold py-2 rounded-lg hover:bg-blue-500 transition-colors shadow-lg shadow-blue-900/20">
            تفعيل Production
          </button>
        </div>
      </div>
    </aside>
  );
}
