import { Bell, Menu, Search, UserCircle } from "lucide-react";

interface HeaderProps {
  onMenuClick?: () => void;
}

export default function Header({ onMenuClick }: HeaderProps) {
  return (
    <header className="h-16 bg-[#0a0c10] border-b border-slate-800 flex items-center justify-between px-4 md:px-6 shrink-0 z-10">
      <div className="flex items-center gap-4 flex-1">
        <button 
          onClick={onMenuClick}
          className="md:hidden text-slate-400 hover:text-white"
        >
          <Menu className="w-6 h-6" />
        </button>
        
        <div className="relative w-full max-w-md hidden md:block">
          <div className="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none">
            <Search className="h-5 w-5 text-slate-400" />
          </div>
          <input
            type="text"
            className="block w-full pl-3 pr-10 py-2 border border-slate-800 rounded-xl leading-5 bg-[#11141b] text-white placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500 sm:text-sm transition-all"
            placeholder="البحث في الحملات، المنتجات..."
          />
        </div>
      </div>

      <div className="flex items-center gap-4">
        <button className="relative p-2 text-slate-400 hover:text-white transition-colors bg-[#11141b] rounded-xl border border-slate-800">
          <span className="absolute top-0 right-0 block h-2 w-2 rounded-full bg-emerald-500 animate-pulse ring-2 ring-[#11141b]" />
          <Bell className="w-5 h-5" />
        </button>
        <div className="h-8 w-px bg-slate-800 hidden md:block"></div>
        <div className="flex items-center gap-3 cursor-pointer p-1.5 rounded-2xl hover:bg-slate-800/50 transition-colors">
          <div className="hidden md:flex flex-col items-end">
            <span className="text-sm font-semibold text-white">أحمد المدير</span>
            <span className="text-[10px] text-slate-500 uppercase tracking-widest font-bold">Marketing Manager</span>
          </div>
          <div className="w-9 h-9 rounded-full bg-gradient-to-tr from-indigo-500 to-purple-500 border-2 border-slate-800 flex items-center justify-center">
            <UserCircle className="w-5 h-5 text-white opacity-50" />
          </div>
        </div>
      </div>
    </header>
  );
}
