import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import "dotenv/config";

// Independent Backend Layers
import { prisma } from "./src/server/db";
import { aiService } from "./src/server/ai";

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json({ limit: "50mb" }));
  app.use(express.urlencoded({ limit: "50mb", extended: true }));

  // --- Core API Routes ---
  app.get("/api/health", (req, res) => {
    res.json({ status: "ok", message: "AI Marketing Command Center API is running" });
  });

  app.get("/api/supervisor/status", (req, res) => {
    res.json({ status: "active", mode: "production_ready" });
  });

  // --- Advisors Manager API ---
  app.get("/api/advisors", async (req, res) => {
    try {
      let advisors = await prisma.advisor.findMany({ orderBy: { createdAt: 'asc' } });
      
      // Auto-seed default advisor if DB is empty
      if (advisors.length === 0) {
        const defaultAdvisor = await prisma.advisor.create({
          data: {
            name: "مستشار المنصة الأساسي",
            roleDescription: "خبير شامل في إدارة المنصة التسويقية.",
            systemPrompt: `أنت مستشار المنصة الأساسي (AI Marketing Command Center). دورك هو تقديم استشارات تسويقية وتقنية، وتنفيذ تعليمات المستخدم بصرامة.\n\nمنهجيتك الأساسية والوحيدة للنجاح هي "خارطة بناء المشروع الأسطوري (Growth OS)" والتي تتكون من 4 ركائز إجبارية:\n\n1. التموضع الذكي (Positioning): صياغة القيمة الفريدة (UVP)، صدمة السوق، وتحليل فجوات المنافسين.\n2. الاستحواذ السريع (Acquisition): قمع مبيعات عالي التحويل (Funnel)، إعلانات موجهة (A/B Testing)، ومحرك SEO.\n3. الأتمتة الذكية (Automation): ربط الـ CRM، متتبعات السلوك، وسلاسل إعادة الاستهداف التلقائية.\n4. القيمة الممتدة (LTV): استراتيجيات Upsell/Cross-sell وبرامج الولاء لرفع قيمة العميل.\n\n[أمر إجباري - شريط حالة النظام]:\nيجب عليك دائماً وفي بداية أي رد أو استجابة لمهام مركبة أن تدرج "شريط حالة العمليات (System Status Bar)" بشكل نصي ليعكس تقدم العمل بدقة كالتالي:\n\n[ 📊 شريط حالة النظام | System Status Bar ]\n[✓] 1. تحليل الطلب والسياق\n[✓] 2. فحص البيانات والملفات\n[⏳] 3. إعداد الحل والتوصيات\n[ ] 4. المراجعة والتسليم النهائي\n\nالحالة الحالية: [النسبة المئوية]% - [وصف مختصر للحالة].\n\nالرموز المعتمدة:\n[✓] مكتمل\n[⏳] قيد المعالجة\n[ ! ] يتطلب إجراء من المستخدم\n[ ] في الانتظار\n\nلا تقبل أو تقترح أي فكرة خارج هذا الإطار. قم دائماً بتحليل طلبات المستخدم وإسقاطها على هذه المصفوفة الرُباعية. تحدث بلهجة الموجه الاستراتيجي والخبير التقني الصارم.`
          }
        });
        advisors = [defaultAdvisor];
      }
      
      res.json(advisors);
    } catch (error) {
      console.error(error);
      res.status(500).json({ error: "Failed to fetch advisors" });
    }
  });

  app.post("/api/advisors", async (req, res) => {
    try {
      const advisor = await prisma.advisor.create({ data: req.body });
      res.json(advisor);
    } catch (error) {
      res.status(500).json({ error: "Failed to create advisor" });
    }
  });

  app.put("/api/advisors/:id", async (req, res) => {
    try {
      const advisor = await prisma.advisor.update({
        where: { id: req.params.id },
        data: req.body
      });
      res.json(advisor);
    } catch (error) {
      res.status(500).json({ error: "Failed to update advisor" });
    }
  });

  app.delete("/api/advisors/:id", async (req, res) => {
    try {
      await prisma.advisor.delete({ where: { id: req.params.id } });
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to delete advisor" });
    }
  });

  // --- Products API ---
  app.get("/api/products", async (req, res) => {
    try {
      const products = await prisma.product.findMany({ orderBy: { createdAt: 'desc' } });
      res.json(products);
    } catch (error) {
      console.error(error);
      res.status(500).json({ error: "Failed to fetch products" });
    }
  });

  app.post("/api/products", async (req, res) => {
    try {
      const data = { ...req.body };
      if (data.price) data.price = parseFloat(data.price);
      
      const product = await prisma.product.create({ data });
      res.json(product);
    } catch (error) {
      console.error(error);
      res.status(500).json({ error: "Failed to create product" });
    }
  });

  app.put("/api/products/:id", async (req, res) => {
    try {
      const data = { ...req.body };
      if (data.price) data.price = parseFloat(data.price);
      
      const product = await prisma.product.update({
        where: { id: req.params.id },
        data
      });
      res.json(product);
    } catch (error) {
      console.error(error);
      res.status(500).json({ error: "Failed to update product" });
    }
  });

  app.delete("/api/products/:id", async (req, res) => {
    try {
      await prisma.product.delete({ where: { id: req.params.id } });
      res.json({ success: true });
    } catch (error) {
      console.error(error);
      res.status(500).json({ error: "Failed to delete product" });
    }
  });

  // --- Dynamic Advisor AI Gateway ---
  app.post("/api/advisor", async (req, res) => {
    try {
      const { prompt, advisorId } = req.body;
      
      let systemInstruction = `أنت مستشار المنصة (AI Marketing Command Center). 
دورك هو تقديم استشارات تسويقية وتقنية، وتنفيذ تعليمات المستخدم بالحرف الواحد بصرامة ودقة. 
أنت تجيب بصفتك مستشار المنصة، لا تغير دورك أو صفاتك.`;
      let model = "gemini-3.6-flash";
      let temperature = 0.7;

      if (advisorId) {
        const advisorInfo = await prisma.advisor.findUnique({
          where: { id: advisorId }
        });
        if (advisorInfo) {
          systemInstruction = advisorInfo.systemPrompt;
          model = advisorInfo.model || model;
          temperature = advisorInfo.temperature || temperature;
        }
      }

      // Delegate generating content to the new independent AI service
      const responseText = await aiService.generate({
        prompt,
        systemInstruction,
        model,
        temperature,
      });

      res.json({ text: responseText });
    } catch (error) {
      console.error(error);
      res.status(500).json({ error: "Failed to generate response" });
    }
  });

  // --- Vite Middleware for Development ---
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    // --- Production Static Serving ---
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer().catch(console.error);
