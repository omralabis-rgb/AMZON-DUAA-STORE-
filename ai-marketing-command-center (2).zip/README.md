# AI Marketing Command Center

منصة إدارة تسويقية متكاملة تعتمد على الذكاء الاصطناعي (Multi-Agent System) لإدارة المحتوى، الحملات، وتحليل البيانات.

## المتطلبات الأساسية
- Node.js (v18 أو أحدث)
- مفتاح API الخاص بـ Gemini (`GEMINI_API_KEY`)

## إعداد المشروع للتشغيل المحلي (Development)

1. **تثبيت الحزم (Dependencies):**
   ```bash
   npm install
   ```

2. **إعداد متغيرات البيئة:**
   قم بإنشاء ملف `.env` (أو نسخ `.env.example` وتعديله) وأضف المفتاح الخاص بك:
   ```bash
   GEMINI_API_KEY="your_gemini_api_key_here"
   ```

3. **إعداد قاعدة البيانات (Prisma):**
   لإنشاء قاعدة بيانات SQLite محلياً ورفع التعديلات الأولية:
   ```bash
   npx prisma db push
   npx prisma generate
   ```

4. **إضافة البيانات الأولية (Seeding):**
   لإضافة المستشارين الافتراضيين لقاعدة البيانات:
   ```bash
   npx prisma db seed
   ```

5. **تشغيل خادم التطوير:**
   ```bash
   npm run dev
   ```
   سيتم تشغيل المشروع على الرابط: `http://localhost:3000`

## البناء للإنتاج (Production)

لعمل Build للمشروع ليصبح جاهزاً للإنتاج:
```bash
npm run build
```
لتشغيل النسخة المبنية (Production Server):
```bash
npm run start
```

## التقنيات المستخدمة
- React 19 + TypeScript
- Vite
- Express (Full-Stack Setup)
- Prisma (SQLite)
- Tailwind CSS (v4)
- Google Gen AI SDK (`@google/genai`)
- Lucide React (Icons)
