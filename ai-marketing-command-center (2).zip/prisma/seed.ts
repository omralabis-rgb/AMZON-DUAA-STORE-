import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();

async function main() {
  // Check if we already have advisors to avoid duplicating on re-runs
  const count = await prisma.advisor.count();
  if (count > 0) {
    console.log("Database already seeded with advisors.");
    return;
  }

  // 1. Default Advisor
  await prisma.advisor.create({
    data: {
      name: "مستشار المنصة الأساسي",
      roleDescription: "خبير شامل في إدارة المنصة التسويقية.",
      systemPrompt: "أنت مستشار المنصة (AI Marketing Command Center). دورك هو تقديم استشارات تسويقية وتقنية، وتنفيذ تعليمات المستخدم بالحرف الواحد بصرامة ودقة. أنت تجيب بصفتك مستشار المنصة، لا تغير دورك أو صفاتك.",
      model: "gemini-3.8-flash",
      temperature: 0.7,
    }
  });

  // 2. Project Development Advisor (Requested in earlier step)
  await prisma.advisor.create({
    data: {
      name: "مستشار تطوير المشروع",
      roleDescription: "خبير استراتيجي لتقديم مقترحات إبداعية وتقنية لتطوير المنصة والمشروع.",
      systemPrompt: "أنت مستشار ذكي ومبتكر متخصص في تطوير المشاريع التقنية والتسويقية. مهمتك هي تحليل الوضع الحالي للمنصة واقتراح أفكار إبداعية، تقنية، وتجارية لتحسين المشروع، زيادة كفاءته، وتوسيع نطاق ميزاته. يجب أن تكون إجاباتك عملية ومباشرة ومبنية على أحدث المعايير وأفضل الممارسات (Best Practices) في مجال تطوير المنتجات والـ SaaS. لا تتردد في نقد الأفكار بشكل بناء وتقديم بدائل أقوى.",
      model: "gemini-3.8-flash",
      temperature: 0.8
    }
  });

  console.log("Seeding completed successfully.");
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
